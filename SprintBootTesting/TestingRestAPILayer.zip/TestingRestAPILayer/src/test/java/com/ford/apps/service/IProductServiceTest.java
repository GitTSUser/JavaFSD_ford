package com.ford.apps.service;

import com.ford.apps.entity.Product;
import com.ford.apps.repository.IProductRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.BDDMockito;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.willDoNothing;
import static org.mockito.Mockito.times;

@ExtendWith(MockitoExtension.class)
class IProductServiceTest {


    @Mock
    private IProductRepository productRepository;

    @InjectMocks
    private ProductServiceImpl productService;


    @Test
    void getAllProducts() {
        //given
        Product p1= Product.builder().id(1001L).name("fan").price(4500.25).qty(20).build();
        Product p2= Product.builder().id(1002L).name("chair").price(6500.25).qty(10).build();
        Product p3= Product.builder().id(1003L).name("laptop").price(44500.25).qty(12).build();
        List<Product> productList=Arrays.asList(p1,p2,p3);
        productRepository.saveAll(productList);
        given(productRepository.findAll()).willReturn(productList);

       //when
        List<Product> receivedProducts=productService.getAllProducts();

        //then
        assertThat(receivedProducts).isNotNull();
        assertThat(receivedProducts.size()).isEqualTo(3);
    }

    @Test
    void getProductById() {

        //given
        Product p1=Product.builder().id(1001L).name("fan").price(2500.25).qty(12).build();
        productRepository.save(p1);
        given(productRepository.findById(p1.getId())).willReturn(Optional.of(p1));

        //when
        System.out.println("product is:"+p1);
        Optional<Product> optionalReceievedProduct=productService.getProductById(1001L);
        Product receievedProduct=optionalReceievedProduct.get();
        //then
        assertThat(receievedProduct).isNotNull();
        assertThat(receievedProduct.getName()).isEqualTo("fan");
        assertThat(receievedProduct.getPrice()).isEqualTo(2500.25);

    }

    @Test
    void updateProduct() {

        //given
        Product product=Product.builder().id(1001L).name("fan").price(2500.25).qty(12).build();
        productRepository.save(product);

        given(productRepository.findById(product.getId())).willReturn(Optional.of(product));
        given(productRepository.save(product)).willReturn(product);

        //when
        Optional<Product> optional=productService.getProductById(product.getId());
        Product receivedProduct=optional.get();
        receivedProduct.setName("super-fan");
        receivedProduct.setPrice(4500.25);
       Product updatedProduct= productService.saveProduct(receivedProduct);

        //then
        assertThat(updatedProduct).isNotNull();
        assertThat(updatedProduct.getName()).isEqualTo("super-fan");
        assertThat(updatedProduct.getPrice()).isEqualTo(4500.25);
    }

    @Test
    void deleteProduct() {

        //given
        Product product=Product.builder().id(1001L).name("fan").price(2500.25).qty(4).build();
        productRepository.save(product);
        willDoNothing().given(productRepository).deleteById(product.getId());

        //when
        productService.deleteProduct(1001L);

        //then
        BDDMockito.verify(productRepository,times(1)).deleteById(1001L);

    }
}