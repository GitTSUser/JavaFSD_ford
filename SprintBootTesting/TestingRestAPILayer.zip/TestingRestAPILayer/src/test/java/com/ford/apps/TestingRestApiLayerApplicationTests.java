package com.ford.apps;

import com.ford.apps.controller.ProductController;
import com.ford.apps.controller.ProductControllerTest;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = {TestingRestApiLayerApplication.class, ProductControllerTest.class})
class TestingRestApiLayerApplicationTests {

	@Test
	void contextLoads() {
	}

}
