package com.ford.apps.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ford.apps.entity.Product;
import com.ford.apps.service.ProductServiceImpl;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(ProductController.class)
public class ProductControllerTest {

    private static final String END_POINT_BASE_PATH="/api/products";

    @MockBean
    private ProductServiceImpl productService;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private MockMvc mockMvc;

    @Test
    void getAllProducts() throws Exception {
        //given
        Product product1= Product.builder().id(1001L).name("fan").price(2500.25).qty(12).build();
        Product product2= Product.builder().id(1002L).name("chair").price(500.25).qty(10).build();
        Product product3= Product.builder().id(1003L).name("lappy").price(45000.25).qty(5).build();
        List<Product> productList= Arrays.asList(product1,product2,product3);
        productService.saveProduct(product1);
        productService.saveProduct(product2);
        productService.saveProduct(product3);
        given(productService.getAllProducts()).willReturn(productList);

        //when
        mockMvc.perform(get(END_POINT_BASE_PATH))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$[0].id").value(1001))
                .andExpect(jsonPath("$[0].name").value("fan"))
                .andExpect(jsonPath("$[0].price").value(2500.25));
        //then
            verify(productService,times(1)).getAllProducts();
    }

    @Test
    void getProductById() {
    }

    @Test
    void createProduct() throws Exception {

        //given
            Product product=Product.builder().id(1001L).name("fan").price(2500.25).qty(25).build();
            //productService.saveProduct(product);
            given(productService.saveProduct(product)).willReturn(product);

         //when
            mockMvc.perform(post(END_POINT_BASE_PATH)
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper.writeValueAsString(product)))
                    .andExpect(status().isCreated())
                    .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                    .andExpect(jsonPath("$.id").value(1001L))
                    .andExpect(jsonPath("$.name").value("fan"))
                    .andExpect(jsonPath("$.price").value(2500.25));

        //then

            verify(productService,times(1)).saveProduct(product);
    }

    @Test
    void updateProduct() throws Exception {
        long productId = 1L;
        Product existingProduct = new Product(productId, "Existing Product", 20.0,12);
        Product updatedProduct = new Product(productId, "Updated Product", 25.0,5);

        given(productService.getProductById(productId)).willReturn(Optional.of(existingProduct));
        when(productService.saveProduct(any(Product.class))).thenReturn(updatedProduct);

        mockMvc.perform(put(END_POINT_BASE_PATH+"/{id}", productId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(new ObjectMapper().writeValueAsString(updatedProduct)))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.id").value(productId))
                .andExpect(jsonPath("$.name").value("Updated Product"))
                .andExpect(jsonPath("$.price").value(25.0));

        verify(productService, times(1)).getProductById(productId);
        verify(productService, times(1)).saveProduct(any(Product.class));
        verifyNoMoreInteractions(productService);


    }

    @Test
    void deleteProduct() {
    }
}