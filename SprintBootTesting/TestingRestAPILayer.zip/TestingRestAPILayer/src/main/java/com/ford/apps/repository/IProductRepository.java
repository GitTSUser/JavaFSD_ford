package com.ford.apps.repository;// IProductRepository.java
import com.ford.apps.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface IProductRepository extends JpaRepository<Product, Long> {
    // Additional queries can be added if needed

    @Query("select p from Product p where p.name=?1 and p.qty=?2")
    Product findByJPQL(String productName,int quantity);

    @Query("select p from Product p where p.name=:productName")
  Product findByName(@Param("productName")String fan);
}
