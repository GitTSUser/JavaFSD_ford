package com.ford.apps.controller;

import com.ford.apps.entity.Product;
import com.ford.apps.service.IProductService;
import org.junit.jupiter.api.Test;
import org.mockito.BDDMockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.List;

import static org.awaitility.Awaitility.given;
import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.http.converter.json.Jackson2ObjectMapperBuilder.json;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest
class ProductControllerTest {

    @MockBean
    private IProductService productService;

    @Autowired
    private MockMvc mockMvc;

    @Test
    void getAllProducts() throws Exception {

        //given
        Product p1= Product.builder().id(1001L).name("fan").price(4500.25).qty(20).build();
        Product p2= Product.builder().id(1002L).name("chair").price(6500.25).qty(10).build();
        Product p3= Product.builder().id(1003L).name("laptop").price(44500.25).qty(12).build();
        List<Product> productList= Arrays.asList(p1,p2,p3);
        productService.saveProduct(p1);
        productService.saveProduct(p2);
        productService.saveProduct(p3);

        //when
        BDDMockito.given(productService.getAllProducts()).willReturn(productList);

        //then
        mockMvc.perform(get("/api/products"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$[0].id").value(1001L))
                .andExpect(jsonPath("$[0].name").value("bag"));
    }

    @Test
    void getProductById() {
    }

    @Test
    void createProduct() {
    }

    @Test
    void updateProduct() {
    }

    @Test
    void deleteProduct() {
    }
}