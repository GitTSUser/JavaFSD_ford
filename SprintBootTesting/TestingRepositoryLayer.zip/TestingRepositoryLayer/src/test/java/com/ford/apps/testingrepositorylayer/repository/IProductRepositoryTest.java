package com.ford.apps.testingrepositorylayer.repository;

import com.ford.apps.testingrepositorylayer.entity.Product;
import org.jboss.logging.Logger;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
class IProductRepositoryTest {

    Logger logger= Logger.getLogger(IProductRepositoryTest.class);
    @Autowired
    private IProductRepository productRepository;

    @Test
    public void testAddProduct() {
        //given
        Product product = Product.builder().id(1L).name("fan").price(2500.25).build();
        //when
        Product savedProduct = productRepository.save(product);
        //then
        assertThat(savedProduct).isNotNull();
        assertThat(savedProduct.getName()).isEqualTo("fan");
        assertThat(savedProduct.getPrice()).isEqualTo(2500.25);
    }


    @Test
    public void testGetAllProducts() {
        //given
        Product product = Product.builder().id(1L).name("fan").price(2500.25).build();
        Product product2 = Product.builder().id(2L).name("mouse").price(500.25).build();
        Product product3 = Product.builder().id(3L).name("lappy").price(42500.25).build();

        //when
        productRepository.saveAll(Arrays.asList(product2,product3,product));

        //then
        List<Product> receivedList=productRepository.findAll();

        assertThat(receivedList).isNotEmpty();
        assertThat(receivedList.size()).isEqualTo(3);

    }


    @Test
    public void getProductById() {
        //given products
        Product product = Product.builder().name("fan").price(4500.25).qty(5).build();
        productRepository.save(product);

        //when find products applied
        Optional<Product> foundProducts = productRepository.findById(1L);
        Product p = foundProducts.get();

        //verify products returned
        assertThat(foundProducts.isPresent()).isEqualTo(true);
        assertThat(foundProducts.get().getName()).isEqualTo("fan");
        logger.info("foundProduct is:: " + p);
    }


    @Test
    public void updateProduct() {

        logger.info("testUpdateProduct is started");
        //give into repository
        productRepository.save(Product.builder().name("fan").price(45000.25).qty(5).build());

        //when add behavior
        Product foundProduct = productRepository.findByName("fan");
        foundProduct.setName("chair");
        foundProduct.setQty(50);
        Product updatedProduct = productRepository.save(foundProduct);

        //verify
        assertThat(updatedProduct.getId()).isEqualTo(2L);
        assertThat(updatedProduct.getName()).isEqualTo("chair");
        assertThat(updatedProduct.getQty()).isEqualTo(50);
    }


    @Test
    public void getProductByNameAndQty(){

        //give data to repository
        Product p=productRepository.save(Product.builder().id(1L).name("fan").price(45000.25).qty(5).build());

        //when applied behavior
        Product foundProduct=productRepository.findByJPQL("fan",5);

        //verify behavior
        assertThat(foundProduct).isNotNull();
        assertThat(foundProduct.getName()).isEqualTo("fan");
        assertThat(foundProduct.getPrice()).isEqualTo(45000.25);
    }
}