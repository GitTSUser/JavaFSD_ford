package com.ford.apps.testingrepositorylayer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestingRepositoryLayerApplicationTests {

	@Test
	void contextLoads() {
	}

}
