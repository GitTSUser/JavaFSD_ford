package com.ford.apps.testingrepositorylayer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestingRepositoryLayerApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestingRepositoryLayerApplication.class, args);
	}

}
