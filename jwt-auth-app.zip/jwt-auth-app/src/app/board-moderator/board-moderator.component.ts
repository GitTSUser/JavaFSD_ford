import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-board-moderator',
  template: `
    <p>
      board-moderator works!
    </p>
  `,
  styles: [
  ]
})
export class BoardModeratorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
