import { Component, OnInit } from '@angular/core';
import { TokenStorageService } from './../_services/token-storage.service';

@Component({
  selector: 'app-profile',
  template: `
   <div class="container" *ngIf="currentUser; else loggedOut">
  <header class="jumbotron">
    <h3>
      <strong>{{ currentUser.username }}</strong> Profile
    </h3>
  </header>
  <p>
    <strong>Token:</strong>
    {{ currentUser.accessToken.substring(0, 20) }} ...
    {{ currentUser.accessToken.substr(currentUser.accessToken.length - 20) }}
  </p>
  <p>
    <strong>Email:</strong>
    {{ currentUser.email }}
  </p>
  <strong>Roles:</strong>
  <ul>
    <li *ngFor="let role of currentUser.roles">
      {{ role }}
    </li>
  </ul>
</div>

<ng-template #loggedOut>
  Please login.
</ng-template>
  `,
  styles: [
  ]
})
export class ProfileComponent implements OnInit {

  currentUser:any;

  constructor(private tokenStorageService:TokenStorageService) { }

  ngOnInit(): void {
    this.currentUser=this.tokenStorageService.getUser();
  }

}
