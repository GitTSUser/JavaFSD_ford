import { Component, OnInit } from '@angular/core';
import { UserService } from '../_services/user.service';

@Component({
  selector: 'app-home',
  template: `
    <div class="container">
      <header class="jumbotron bg-info text-warning">
        <h2>{{ content }}</h2>
        <p class="text-white">
          Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores
          corporis inventore, modi earum saepe natus ducimus beatae ex tempore
          voluptate labore accusantium quis atque magni hic laboriosam
          cupiditate vitae unde.
        </p>
        <p class="text-white">
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Nulla
          voluptas quidem vel, esse neque cupiditate labore corporis maxime enim
          aspernatur nobis! Rem placeat nostrum nam cumque veniam repellendus
          facilis animi.
        </p>
      </header>
    </div>
  `,
  styles: [],
})
export class HomeComponent implements OnInit {
  content?: string = 'WWW';

  constructor(private userService: UserService) {}

  ngOnInit(): void {
    this.userService.getPublicContent().subscribe({
      next: (data) => {
        this.content = data;
      },
      error: (err) => {
        this.content = JSON.parse(err.error).message;
      },
    });
  }
}
