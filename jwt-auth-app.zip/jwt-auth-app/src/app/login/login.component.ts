import { Component, OnInit } from '@angular/core';
import { AuthService } from '../_services/auth.service';
import { TokenStorageService } from '../_services/token-storage.service';

@Component({
  selector: 'app-login',
  template: `
    <div class="col-md-12">
    <h3 class="text-center text-white text-uppercase bg-info">Login Here</h3>
      <div class="card card-container">
        <!--<img
          id="profile-img"
          src="//ssl.gstatic.com/accounts/ui/avatar_2x.png"
          class="profile-img-card"
        />-->
        <form
          *ngIf="!isLoggedIn"
          name="form"
          (ngSubmit)="f.form.valid && onSubmit()"
          #f="ngForm"
          novalidate
        >
          <div class="form-group">
            <label for="username">Username</label>
            <input
              type="text"
              class="form-control"
              name="username"
              [(ngModel)]="form.username"
              required
              #username="ngModel"
            />
            <div
              class="alert alert-danger"
              role="alert"
              *ngIf="username.errors && f.submitted"
            >
              Username is required!
            </div>
          </div>
          <div class="form-group">
            <label for="password">Password</label>
            <input
              type="password"
              class="form-control"
              name="password"
              [(ngModel)]="form.password"
              required
              minlength="6"
              #password="ngModel"
            />
            <div
              class="alert alert-danger"
              role="alert"
              *ngIf="password.errors && f.submitted"
            >
              <div *ngIf="password.errors['required']">
                Password is required
              </div>
              <div *ngIf="password.errors['minlength']">
                Password must be at least 6 characters
              </div>
            </div>
          </div>
          <div class="form-group">
            <button class="btn btn-primary btn-block">Login</button>
          </div>
          <div class="form-group">
            <div
              class="alert alert-danger"
              role="alert"
              *ngIf="f.submitted && isLoginFailed"
            >
              Login failed: {{ errorMessage }}
            </div>
          </div>
        </form>

        <div class="alert alert-success" *ngIf="isLoggedIn">
          Logged in as {{ roles }}.
        </div>
      </div>
    </div>
  `,
  styles: [],
})
export class LoginComponent implements OnInit {
  form: any = {
    username: null,
    password: null,
  };

  isLoggedIn = false;
  isLoginFailed = false;
  errorMessage = '';
  roles: string[] = [];

  constructor(
    private authService: AuthService,
    private tokenStorageService: TokenStorageService
  ) {}

  ngOnInit(): void {
    if (this.tokenStorageService.getToken()) {
      this.isLoggedIn = true;
      this.roles = this.tokenStorageService.getUser().roles;
    }
  }

  onSubmit(): void {
    const { username, password } = this.form;

    this.authService.login(username, password).subscribe({
      next: (data) => {
        this.tokenStorageService.saveToken(data.accessToken);
        this.tokenStorageService.saveUser(data);

        this.isLoginFailed = false;
        this.isLoggedIn = true;
        this.roles = this.tokenStorageService.getUser().roles;
        this.reloadPage();
      },
      error: (err) => {
        this.errorMessage = err.error.message;
        this.isLoginFailed = true;
      },
    });
  }

  reloadPage(): void {
    window.location.reload();
  }
}
