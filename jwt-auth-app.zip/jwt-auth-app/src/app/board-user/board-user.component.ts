import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-board-user',
  template: `
    <p>
      board-user works!
    </p>
  `,
  styles: [
  ]
})
export class BoardUserComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
