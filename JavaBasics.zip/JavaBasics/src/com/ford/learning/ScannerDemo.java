package com.ford.learning;

import java.util.Scanner;

public class ScannerDemo {
    public static void main(String[] args) {
        // Creating a Scanner object to read input from the console
        Scanner scanner = new Scanner(System.in);


        // Reading and printing an integer
        System.out.print("Enter your age: ");
        int age = scanner.nextInt();
        System.out.println("You are " + age + " years old.");

        scanner.nextLine();
        
        // Reading and printing a string
         System.out.print("Enter your name: ");
        String name = scanner.next();
        System.out.println("Hello, " + name + "!");
        // Reading and printing a double
        System.out.print("Enter your height (in meters): ");
        double height = scanner.nextDouble();
        System.out.println("Your height is: " + height + " meters.");

        // Reading and printing a boolean
        System.out.print("Are you a student? (true/false): ");
        boolean isStudent = scanner.nextBoolean();
        System.out.println("Student status: " + isStudent);

        // Remember to close the scanner to avoid resource leaks
        scanner.close();
    }
}
