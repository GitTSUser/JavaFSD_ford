package com.ford.learning;

public class AppOne {

	public static void main(String[] args) {

		int a = 100;
		int b = 200;

		int c = a + b;

		System.out.println("sum is:" + (a + b));
		System.out.println("sum is:" + c);

		char ch = 'T';

		int myChar = ch;

		System.out.println(ch + " " + myChar);

		byte x = 20;
		byte y = 30;

		byte k = (byte) (y +x);

		System.out.println("k is:" + k);
	}
}