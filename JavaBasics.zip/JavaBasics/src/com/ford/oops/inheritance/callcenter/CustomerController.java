package com.ford.oops.inheritance.callcenter;

public class CustomerController {

	public static void main(String[] args) {

		Customer customer = new Customer("varun", "golden", 8855994422L);
		Customer customer2 = new Customer("arun", "premium", 8855994422L);
		Customer customer3 = new Customer("tarun", "silver", 8855994422L);

		customer.printCustomerInfo();

		customer2.printCustomerInfo();

		customer3.printCustomerInfo();
		customer.printCustomerInfo();

		CallCenter.makeCallToCallCenter(customer3);

	}
}
