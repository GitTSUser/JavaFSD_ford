//program to demonstrate single inheritance in java

package com.ford.oops.inheritance;

class Super {

	int breadth;
	public Super(int breadth) {
		this.breadth = breadth;
		System.out.println("Super() constructor");
	}
}

class Sub extends Super {

	int width;
	public Sub(int width, int breadth) {
		super(breadth);
		this.width = width;
		System.out.println("Sub() constructor called");
	}
}

class AnotherSub extends Sub {

	public AnotherSub(int width, int breadth) {
		super(width, breadth);
		System.out.println("AnotherSub() constructor called");
	}

	public int findArea() {
		return width * breadth;
	}
}

public class InheritanceDemo {

	public static void main(String[] args) {

		AnotherSub anotherSubObj = new AnotherSub(20, 40);

		int area = anotherSubObj.findArea();

		System.out.println("area is:" + area);
	}
}