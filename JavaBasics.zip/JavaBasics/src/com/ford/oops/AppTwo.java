//program to demonstrate performing banking operations
package com.ford.oops;

class BankAccount {

	private long accountNo;
	private String accountHolderName;
	private String ifscCode;
	private String typeOfAccount;
	private double accountBalance;
	private boolean accountStatus;

	public BankAccount(long accountNo, String accountHolderName, String ifscCode, double accountBalance,
			boolean accountStatus) {

		this.accountBalance = accountBalance;
		this.accountNo = accountNo;
		this.ifscCode = ifscCode;
		this.accountHolderName = accountHolderName;

	}

	public void deposit(double amount) {
		this.accountBalance = this.accountBalance + amount;
		System.out.println("account updated with deposit of:"+amount);
	}

	public void withdraw(double amount) {
		if(amount>this.accountBalance) {
			System.out.println("funds are insufficient!");
			return;
		}
		this.accountBalance = this.accountBalance - amount;
		System.out.println("account updated with withdraw of:"+amount);
	}

	public void printAccountInfo() {
		System.out.println(accountNo + " " + accountBalance);
	}

}

public class AppTwo {

	public static void main(String[] args) {

		BankAccount account = new BankAccount(123456789, "Aravindh", "IDIB000S013", 45000.25, true);

		account.printAccountInfo();
		
		account.deposit(5000);
		account.printAccountInfo();
		account.withdraw(120000);
		account.printAccountInfo();
		
		
	}
}
