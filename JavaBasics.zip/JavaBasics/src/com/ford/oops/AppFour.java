package com.ford.oops;

import java.util.Arrays;

public class AppFour {

	public static void main(String[] args) {

		int numArr[] = new int[6];

		numArr[0] = 10;
		numArr[1] = 2;
		numArr[2] = 30;
		numArr[3] = 22;
		numArr[4] = 32;
		numArr[5] = 60;

		System.out.println("no.of elements are:" + numArr.length);

		System.out.println(Arrays.toString(numArr));

		Arrays.sort(numArr);

		System.out.println(Arrays.toString(numArr));

		// find the prefix sum of array
		int prefixSumArr[] = getPrefixSum(numArr);

		System.out.println("prefixSum array is:" + Arrays.toString(prefixSumArr));

	}

	private static int[] getPrefixSum(int[] numArr) {

		int resultArr[] = new int[numArr.length];

		int curSum = 0;
		for (int i = 0; i < numArr.length; i++) {

			resultArr[i] = numArr[i] + curSum;
			curSum = resultArr[i];
		}

		return resultArr;
	}
}