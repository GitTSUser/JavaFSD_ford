package com.ford.oops.zoo;

public abstract class AbstractAnimal implements Animal {

	@Override
	public void eat() {
		System.out.println("animal eats food");

	}

	@Override
	public void sleep() {

		System.out.println("animal sleeps");
	}

}
