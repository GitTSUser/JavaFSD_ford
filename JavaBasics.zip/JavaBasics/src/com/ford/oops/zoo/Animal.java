package com.ford.oops.zoo;

public interface Animal {

	public void eat();

	public void move();

	public void sleep();
}
