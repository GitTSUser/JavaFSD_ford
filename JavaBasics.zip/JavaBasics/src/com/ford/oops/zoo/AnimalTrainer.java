package com.ford.oops.zoo;

public class AnimalTrainer {

	public void train(Animal animal) {

		animal.move();
		
		if(animal instanceof Bird) {
			
			Bird bird=(Bird)animal; //donwcasting
			bird.sing();
		}
		
	}

}
