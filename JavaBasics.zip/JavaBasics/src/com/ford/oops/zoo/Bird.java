package com.ford.oops.zoo;

public class Bird extends AbstractAnimal {

	@Override
	public void move() {

		System.out.println("bird flies on wings");
	}

	public void sing() {
		System.out.println("bird sings a song");
	}

}
