package com.ford.oops.overloading.loans;

public class ABCBank {

	public double provideLoan(Customer customer, double loanAmount, int noOfYears) {

		// for customer loan amount should be between 1 lakh to 5 lakhs and noOfYear <
		// 10

		// for golden customer loan amount should between 1 lakh to 10 laksh and
		// noOfYear <20

		// for premium customer loan amount should between 1 lakh to 25 laksh and
		// noOfYear <25

		if (customer instanceof PremiumCustomer) {

			PremiumCustomer premiumCustomer = (PremiumCustomer) customer;

			if (premiumCustomer.getMembershipCount() != 0) {
				return loanAmount;
			}

		} else if (customer instanceof GoldenCustomer) {

			GoldenCustomer goldenCustomer = (GoldenCustomer) customer;

			if (goldenCustomer.getGoldCount() != 0) {

				return loanAmount;
			}
		} else {

			return loanAmount;
		}

		return 0;

	}

}
