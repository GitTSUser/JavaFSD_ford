package com.ford.oops.overloading.loans;

public class Customer {

	private static long genId = 12345678;
	private long id;
	private String name;
	private long phone;

	public Customer(String name, long phone) {
		genId = genId + 1;
		this.id = genId;
		this.name = name;
		this.phone = phone;
	}

	public void setId(long id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setPhone(long phone) {
		this.phone = phone;
	}

	public long getId() {
		return this.id;
	}

	public String getName() {
		return name;
	}

	public long getPhone() {
		return this.phone;
	}

	public void printCustomerInfo() {
		System.out.println(this.id + " " + this.name + " " + this.phone);
	}

}
