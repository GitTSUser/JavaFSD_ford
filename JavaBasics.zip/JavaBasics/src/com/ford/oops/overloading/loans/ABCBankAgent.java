package com.ford.oops.overloading.loans;

public class ABCBankAgent {

	public static boolean processLoan(Customer customer, double loanAmount, int noOfYears) {

		ABCBank bank = new ABCBank();

		System.out.println("loan provided is:"+bank.provideLoan(customer, loanAmount, noOfYears));

		return true;
	}

	public static void main(String[] args) {

		PremiumCustomer premiumCustomer = new PremiumCustomer("mohan", 998855445522L, 10);

		processLoan(premiumCustomer, 1500000.00, 5);

		GoldenCustomer goldenCustomer = new GoldenCustomer("kalayavani", 8855221122L, 20);

		processLoan(goldenCustomer, 1500000.00, 5);

	}

}
