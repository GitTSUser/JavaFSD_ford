package com.ford.oops.overloading.loans;

public class PremiumCustomer extends Customer {

	private int membershipCount;

	public PremiumCustomer(String name, long phone, int membershipCount) {
		super(name, phone);
		this.membershipCount = membershipCount;
	}

	public int getMembershipCount() {
		return membershipCount;
	}

	public void setMembershipCount(int membershipCount) {
		this.membershipCount = membershipCount;
	}

	public void printPremiumCustomerInfo() {

		super.printCustomerInfo();
		System.out.println("premium customer memberships :" + membershipCount);
	}

}
