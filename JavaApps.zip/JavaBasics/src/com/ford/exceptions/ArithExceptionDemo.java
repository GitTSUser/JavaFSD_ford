//program to demonstrate basic exception handling

package com.ford.exceptions;

public class ArithExceptionDemo {

	public void doDivision(int x, int y) {

		try {

			int z = x / y;
			System.out.println("division is:" + z);

		} catch (ArrayIndexOutOfBoundsException exception) {
			System.out.println("exception is:" + exception.getMessage());
		}

		System.out.println("end of the doDivision method");
	}

	public static void main(String[] args) {

		ArithExceptionDemo obj = new ArithExceptionDemo();

		try {

			obj.doDivision(40, 0);
		} catch (ArithmeticException exception) {
			System.out.println("exception in main:" + exception.getMessage());
		}
		System.out.println("end of program");

	}

}
