package com.ford.exceptions.custom;

public class BankAccount {

	private long accountNo;
	private String accountHolderName;
	private double balace;

	public BankAccount(String accountHolderName, double balace) {
		super();
		this.accountNo = (long) (Math.abs(Math.random())*12345678);
		this.accountHolderName = accountHolderName;
		this.balace = balace;
	}

	@Override
	public String toString() {
		return "BankAccount [accountNo=" + accountNo + ", accountHolderName=" + accountHolderName + ", balace=" + balace
				+ "]";
	}

}
