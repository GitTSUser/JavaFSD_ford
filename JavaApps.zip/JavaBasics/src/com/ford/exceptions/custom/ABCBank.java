package com.ford.exceptions.custom;

public class ABCBank {

	public BankAccount openAccount(Person person, String accounType, double amount) {

		if (person.getAge() >= 18 && person.getAge() <= 60) {

			return new BankAccount(person.getName(), amount);
		} else {
			throw new InvalidPersonDetailsException("Person age is not valid to open account");
		}

	}

}
