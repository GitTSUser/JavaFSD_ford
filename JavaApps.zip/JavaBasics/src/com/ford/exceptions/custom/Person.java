package com.ford.exceptions.custom;

public class Person {

	private long adhaar;
	private String name;
	private int age;

	public Person(long adhaar, String name, int age) {
		super();
		this.adhaar = adhaar;
		this.name = name;
		this.age = age;
	}

	public long getAdhaar() {
		return adhaar;
	}

	public void setAdhaar(long adhaar) {
		this.adhaar = adhaar;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public String toString() {
		return "Person [adhaar=" + adhaar + ", name=" + name + ", age=" + age + "]";
	}

}
