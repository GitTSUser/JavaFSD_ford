package com.ford.exceptions.custom;

public class Main {

	public static void main(String[] args) {

		ABCBank bank = new ABCBank();

		Person person = new Person(123456789, "Abhi", 40);

		Person person2 = new Person(423456789, "ArunKumar", 17);

		try {
			BankAccount account = bank.openAccount(person, "Savings", 5000);
			System.out.println(account);
			BankAccount account2 = bank.openAccount(person2, "Savings", 6000);
			System.out.println(account2);
		} catch (InvalidPersonDetailsException ipde) {
			System.out.println(ipde);
		}
		System.out.println("end of program");
	}

}
