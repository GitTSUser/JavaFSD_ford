package com.ford.exceptions.custom;

public class InvalidPersonDetailsException extends RuntimeException {

	private String exceptionMessage;

	public InvalidPersonDetailsException(String exceptionMessage) {
		this.exceptionMessage = exceptionMessage;
	}

	public String toString() {
		return this.exceptionMessage;
	}

}
