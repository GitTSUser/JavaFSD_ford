package com.ford.exceptions;

import java.util.Scanner;

public class ThrowDemo {

	public static void m3() {
		Scanner scanner = new Scanner(System.in);

		int x, y;

		System.out.println("enter any number:");
		x = scanner.nextInt();
		System.out.println("enter another:");
		y = scanner.nextInt();

		try {

			if (y == 0) {
				throw new ArithmeticException(" y value must be non-zero");
			}

			int z = x / y;

			System.out.println("div is:" + z);
		} catch (ArithmeticException exception) {
			// System.out.println("exception is:" + exception.getMessage());
			throw exception; //re-throwing
		}

	}

	public static void m2() {

		m3();
	}

	public static void m1() {
		m2();
	}

	public static void main(String[] args) {

		try {
			m1();

		} catch (ArithmeticException exception) {
			System.out.println("in main, exception is:" + exception.getMessage());
		}
		System.out.println("end of program");

	}
}
