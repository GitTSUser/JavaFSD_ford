package com.ford.exceptions;

import java.util.InputMismatchException;
import java.util.Scanner;

public class RightInputReading {

	public static void main(String[] args) {

		int x, y;
		boolean flag = true;

		while (flag) {
			try {
				Scanner scanner = new Scanner(System.in);
				System.out.println("enter any number:");
				x = scanner.nextInt();

				System.out.println("enter another :");
				y = scanner.nextInt();

				System.out.println("x is:" + x);
				System.out.println("y is:" + y);
				flag = false;
				scanner.close();
			} catch (InputMismatchException ime) {
				System.out.println("you entered wrong input, pls re-enter");
			}
		}

		System.out.println("end of program");
	}

}
