package com.ford.exceptions;

import java.io.IOException;
import java.util.Scanner;

public class ThrowsDemo3 {

	public static void m3() throws IOException,ClassNotFoundException {
		Scanner scanner = new Scanner(System.in);

		int x, y;

		System.out.println("enter any number:");
		x = scanner.nextInt();
		System.out.println("enter another:");
		y = scanner.nextInt();

		if (y == 0) {
			throw new IOException(" y value must be non-zero");
		}

		int z = x / y;
		System.out.println("div is:" + z);

	}

	public static void m2() throws IOException, ClassNotFoundException {

		m3();
	}

	public static void m1() throws IOException, ClassNotFoundException {
		m2();
	}

	public static void main(String[] args) throws ClassNotFoundException {

		try {
			m1();

		} catch (IOException exception) {
			System.out.println("in main, exception is:" + exception.getMessage());
		}
		System.out.println("end of program");

	}
}
