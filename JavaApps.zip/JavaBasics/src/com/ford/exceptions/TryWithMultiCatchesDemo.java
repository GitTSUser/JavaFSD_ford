package com.ford.exceptions;

import java.util.InputMismatchException;
import java.util.Scanner;

public class TryWithMultiCatchesDemo {

	public static void main(String[] args) {

		try {

			Scanner scanner = new Scanner(System.in);

			System.out.println("Enter any number:");
			int x = scanner.nextInt();
			System.out.println("Enter another:");
			int y = scanner.nextInt();

			int z = x / y;
			System.out.println("div of x,y is:" + z);

		} catch (ArithmeticException ae) {
			System.out.println("ArithmeticException is:" + ae.getLocalizedMessage());
		} catch (InputMismatchException ae) {
			System.out.println("InputMismatchException is:" + ae.getLocalizedMessage());
		} catch (Exception e) {
			System.out.println("exception is:" + e.getMessage());
		}

	}

}
