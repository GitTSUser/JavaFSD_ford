package com.ford.exceptions;

class Employ {
	private int id;
	private String name;
	private double salary;

	public Employ(int id, String name, double salary) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
	}

	public String toString() {
		return this.id + " " + this.name + " " + this.salary;
	}

}

public class ToStringDemo {

	public static void main(String[] args) {

		Employ employ = new Employ(1001, "arun kumar", 45000);

		System.out.println("Employ info:" + employ);

	}

}
