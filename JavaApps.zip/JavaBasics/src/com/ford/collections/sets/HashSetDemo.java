package com.ford.collections.sets;

import java.util.HashSet;

public class HashSetDemo {

	public static void main(String[] args) {

		HashSet<String> citySet = new HashSet<>();

		citySet.add("Chennai");
		System.out.println(citySet.add("Blore"));
		citySet.add("Hyd");
		citySet.add("Bombay");
		citySet.add("Delhi");
		System.out.println(citySet.add("Blore"));
		System.out.println("No.of elements :"+citySet.size());
		System.out.println(citySet);

		if(citySet.contains("Hyd")) {
			System.out.println("city Hyd is present in set");
		}
		
		
		
		
		
		
		
		
		
	}

}
