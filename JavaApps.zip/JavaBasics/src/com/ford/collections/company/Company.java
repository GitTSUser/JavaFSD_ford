package com.ford.collections.company;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

public class Company {

	private int regNo;
	private String name;
	private ArrayList<Employ> employList;

	public Company(int regNo, String name) {
		this.regNo = regNo;
		this.name = name;
		this.employList = new ArrayList<>();
	}

	// add employ to the company
	public void addEmploy(Employ employ) {

		employList.add(employ);
		System.out.println("employ added in company");
	}

	// update employ project details
	public void updateEmployProject(int employId, String newProject) {

		boolean flag = false;

		for (int i = 0; i < employList.size(); i++) {

			Employ emp = employList.get(i); // taking employ based on index

			if (emp.getId() == employId) { // checking the employ is the one looking for

				HashSet<String> empProjectSet = emp.getProjects(); // getting employ projects
				empProjectSet.add(newProject); // add new project
				System.out.println("project details updated for employ with id:" + employId);
				flag = true;
				break;
			}
		}

		if (flag == false) {
			System.out.println("project details not updated for employ");
		}

	}

	// display employ details who are working in a project

	public void displayEmployList(String projectName) {

		for (Employ emp : employList) { // iterating over employList

			HashSet<String> empProjectSet = emp.getProjects(); // getting employ projects

			if (empProjectSet.contains(projectName)) { // checking given projectname is present in set

				System.out.println(emp.getId() + " " + emp.getName() + " " + empProjectSet); // disply emp details
			}

		}

	}

	// display employ details descending order based on salary

	public void displayEmployListInDescOrderBySalary() {
		
	}

	public ArrayList<Employ> getEmployList() {
		return employList;
	}

	public void setEmployList(ArrayList<Employ> employList) {
		this.employList = employList;
	}

}
