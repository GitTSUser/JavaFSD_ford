package com.ford.collections.company;

import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {

		Company company = new Company(2345, "Ford");

		Employ emp1 = new Employ(1001, "arun", 42000);
		Employ emp2 = new Employ(1003, "varun", 25000);
		Employ emp3 = new Employ(1002, "tarun", 65000);
		Employ emp4 = new Employ(1005, "karun", 44000);
		Employ emp5 = new Employ(1004, "Sundarun", 15000);
		Employ emp6 = new Employ(1006, "Chandarun", 55000);

		company.addEmploy(emp4);
		company.addEmploy(emp5);
		company.addEmploy(emp6);
		company.addEmploy(emp1);
		company.addEmploy(emp2);
		company.addEmploy(emp3);

		ArrayList<Employ> empList = company.getEmployList();

		for (Employ emp : empList) {
			System.out.println(emp.getId() + " " + emp.getName() + " " + emp.getSalary() + "  " + emp.getProjects());
		}

		company.updateEmployProject(1002, "CMS");
		company.updateEmployProject(1002, "BCMS");

		for (Employ emp : empList) {
			System.out.println(emp.getId() + " " + emp.getName() + " " + emp.getSalary() + "  " + emp.getProjects());
		}

	}
}