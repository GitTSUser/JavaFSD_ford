package com.ford.collections;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

class Bike implements Comparable<Bike> {

	int bno;
	String name;

	public Bike(int bno, String name) {
		this.bno = bno;
		this.name = name;
	}

	public int getBno() {
		return bno;
	}

	public void setBno(int bno) {
		this.bno = bno;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Bike [bno=" + bno + ", name=" + name + "]";
	}

	@Override
	public int compareTo(Bike anotherBike) {

		// write the comparision logic means, what to compare in bike

		if (this.getBno() == anotherBike.getBno()) {
			return 0;
		} else if (this.getBno() > anotherBike.getBno()) {
			return 1;
		}

		return -1;
	}

}

class BikeNamedComparator implements Comparator<Bike> {

	@Override
	public int compare(Bike bike1, Bike bike2) {

		return bike1.getName().compareTo(bike2.getName());
	}

}

public class SortObjects {

	public static void main(String[] args) {

		int arr[] = { 20, 30, 12, 1, 6 };

		System.out.println(Arrays.toString(arr));
		Arrays.sort(arr);

		System.out.println(Arrays.toString(arr));

		Bike bike1 = new Bike(1234, "honda");

		Bike bike2 = new Bike(5234, "honda-Activa");

		Bike bike3 = new Bike(7234, "splendor");

		Bike bike4 = new Bike(34, "royalField");

		List<Bike> bikeList = new ArrayList<>();

		bikeList.add(bike4);
		bikeList.add(bike3);
		bikeList.add(bike2);
		bikeList.add(bike1);

		System.out.println(bikeList);

		System.out.println("---sorted by bikeNo in ascending order---");

		Collections.sort(bikeList); // sort based bikeNo or natural comparision

		System.out.println(bikeList);

		System.out.println("---sorted by bikeName in ascending order---");
		Collections.sort(bikeList, new BikeNamedComparator());

		System.out.println(bikeList);

	}

}
