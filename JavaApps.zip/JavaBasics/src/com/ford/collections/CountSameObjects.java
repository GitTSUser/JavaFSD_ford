package com.ford.collections;

import java.util.ArrayList;

public class CountSameObjects {

	public static void main(String[] args) {

		/*
		 * List<String> fruitList = Arrays.asList(new String[] { "apple", "mango",
		 * "apple", "grapes", "banana" });
		 */

		ArrayList<String> fruitList = new ArrayList<>();
		fruitList.add("apple");
		fruitList.add("mango");
		fruitList.add("apple");
		fruitList.add("grapes");
		fruitList.add("banana");

		System.out.println(fruitList);

		// no.of elements in list
		System.out.println("No.of fruits:" + fruitList.size());

		// checks a fruit is present in list
		if (fruitList.contains("mango")) {
			System.out.println("yes , mango is present");
		} else {
			System.out.println("no, mango is not present");
		}

		// replace a fruit in list
		if (fruitList.contains("grapes")) {
			int index = fruitList.indexOf("grapes");

			fruitList.set(index, "Watermelon");
		}

		System.out.println(fruitList);
		fruitList.remove("mango"); // remove a fruit from list
		System.out.println(fruitList);

		ArrayList<String> fruitList2 = new ArrayList<>(fruitList);

		System.out.println("2nd list:" + fruitList2);

		fruitList2.remove(1);
		fruitList2.remove(2);

		System.out.println("2nd list:" + fruitList2);

		// removeAll from fruitList

		fruitList.removeAll(fruitList2);

		System.out.println("1st list:" + fruitList);
		
		
		fruitList.clear();
		
		System.out.println("fruitList is:"+fruitList);

	}
}