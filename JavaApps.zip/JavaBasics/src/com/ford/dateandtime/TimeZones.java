package com.ford.dateandtime;

import java.time.ZoneId;
import java.util.Set;

public class TimeZones {

	public static void main(String[] args) {

		Set<String> zoneIds = ZoneId.getAvailableZoneIds();

		System.out.println("no.of timezones are:"+zoneIds.size());
		for (String zone : zoneIds) {
			if(zone.contains("Pacific")) {
			System.out.println("timezone is:"+zone);
			}
		}

	}
}
