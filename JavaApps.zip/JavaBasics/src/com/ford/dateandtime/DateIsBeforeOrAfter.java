package com.ford.dateandtime;

import java.time.LocalDate;

public class DateIsBeforeOrAfter {

	public static void main(String[] args) {

		LocalDate dateOfBirth = LocalDate.of(2002, 3, 6);

		LocalDate todayDate = LocalDate.now();

		System.out.println("years:" + (todayDate.getYear() - dateOfBirth.getYear()));
		System.out.println("months:" + (dateOfBirth.getMonthValue() - todayDate.getMonthValue()));
		System.out.println("days:" + (todayDate.getDayOfMonth() - dateOfBirth.getDayOfMonth()));

		if(dateOfBirth.isAfter(todayDate)) {
			System.out.println("dateofbirth is after todayDate");
		}else if(dateOfBirth.isBefore(todayDate)) {
			System.out.println("dateOfBirth is before todayDate");
		}else {
			System.out.println("both are same");
		}
	
	}
}