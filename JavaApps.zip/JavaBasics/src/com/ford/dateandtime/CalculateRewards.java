package com.ford.dateandtime;

import java.time.Duration;
import java.time.Period;

public class CalculateRewards {

	public static int findRewards(int noOfTasks, int completedTasks, Period period) {

		// if all tasks completed, give 10 rewards

		if (completedTasks == noOfTasks) {
			return period.getDays() / 9;
		}

		// if 75% tasks completed, give 8 rewards

		if (noOfTasks * 0.75 <= completedTasks) {
			return 8;
		}

		// if 50% tasks completed give 4 rewards
		if (noOfTasks * 0.50 <= completedTasks) {
			return 4;
		}

		// if 30% tasks completed give 2 rewards

		if (noOfTasks * 0.30 <= completedTasks) {
			return 2;
		}

		// if 10% tasks completed give no reward
		return 0;


	}

	public static void main(String[] args) {

		int noOfRewards = findRewards(60, 24, Period.ofDays(180));

		System.out.println("No.of rewards:"+noOfRewards);
		
		
		Period period=Period.ofMonths(2);
		period=period.ofDays(35);

		System.out.println("days are:"+period.getDays());
		System.out.println("months in 2 years:"+period.getMonths());
		System.out.println("years:"+period.getYears());
		
		
		Duration duration=Duration.ofHours(10);
		System.out.println(duration.getSeconds());
		
		
		
		
		
		
	}

}
