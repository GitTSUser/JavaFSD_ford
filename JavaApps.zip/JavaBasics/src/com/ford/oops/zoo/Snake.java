package com.ford.oops.zoo;

public class Snake extends AbstractAnimal {

	@Override
	public void move() {

		System.out.println("snake crawls on the ground");
	}

}
