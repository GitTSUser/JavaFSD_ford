package com.ford.oops.zoo;

public class Main {

	public static void main(String[] args) {

		Bird bird = new Bird();

		bird.eat();
		bird.move();
		bird.sleep();

		Fish fish = new Fish();
		fish.eat();
		fish.move();
		fish.sleep();

		System.out.println("--------Animal calling-------");
		Animal animal;
		animal = fish;
		animal.eat();
		animal.move();
		animal.sleep();

		animal = bird;
		animal.eat();
		animal.move();
		animal.sleep();

		Bird animalBird = (Bird) animal; // downcasting

		animalBird.sing();

		AnimalTrainer animalTrainer = new AnimalTrainer();
System.out.println("---Trainer training to=------");
		animalTrainer.train(bird);
		animalTrainer.train(fish);

	}
}
