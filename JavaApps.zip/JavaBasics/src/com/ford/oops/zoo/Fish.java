package com.ford.oops.zoo;

public class Fish extends AbstractAnimal {

	@Override
	public void move() {

		System.out.println("fish swims in water to move");
	}

}
