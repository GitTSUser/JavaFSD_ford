
//program to demonstrate creation and initialization of objects

package com.ford.oops;

class Vehicle {

	// properties (or) attributes (or) data
	String engineType;
	int noOfTyres;
	int noOfSeats;
	String brand;

}

public class AppOne {

	public static void main(String[] args) {

		Vehicle obj = new Vehicle();

		
		System.out.println("obj:");
		obj.engineType = "petrol";
		obj.noOfTyres=4;
		obj.brand = "ford";
		obj.noOfSeats = 7;

		System.out.println(obj.engineType);
		System.out.println(obj.brand);
		System.out.println(obj.noOfSeats);
		System.out.println(obj.noOfTyres);

		Vehicle obj2=obj;
		
		System.out.println("obj2:");
		System.out.println(obj2.engineType);
		System.out.println(obj2.brand);
		System.out.println(obj2.noOfSeats);
		System.out.println(obj2.noOfTyres);
		
		
		System.out.println("obj is:"+obj);
		System.out.println("obj2 is:"+obj2);
		
	}

}
