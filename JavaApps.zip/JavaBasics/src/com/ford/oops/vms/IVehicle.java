package com.ford.oops.vms;

public interface IVehicle {

	void start();
	void move(String from,String to);
	void stop();
}
