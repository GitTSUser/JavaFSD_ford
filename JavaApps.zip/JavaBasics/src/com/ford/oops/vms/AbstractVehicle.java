package com.ford.oops.vms;

public abstract class AbstractVehicle implements IVehicle {

	String vehicleType;

/*	public AbstractVehicle(String name) {
		this.vehicleType = name;
	}
*/
	public void start() {
		System.out.println(vehicleType + "  started");
	}

	public void stop() {
		System.out.println(vehicleType + " stopped");
	}

}
