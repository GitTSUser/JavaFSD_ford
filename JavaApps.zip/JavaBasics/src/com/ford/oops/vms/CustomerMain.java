package com.ford.oops.vms;

public class CustomerMain {

	public static void main(String[] args) {

/*		Bike bike = (Bike) VehicleAgent.getVehicle("bike");
		bike.start();
		bike.move("Chennai", "Koyambattur");
		bike.stop();

		Car car = (Car) VehicleAgent.getVehicle("car");

		Bus bus = (Bus) VehicleAgent.getVehicle("bus");
		bus.start();
		bus.move("Chennai", "Bangalore");
		bus.stop();
*/
		
		
		IVehicle vehicle = VehicleAgent.getVehicle("bike");
		vehicle.start();
		vehicle.move("Bangalore", "Bombay");
		vehicle.stop();
		
		
		
		
		
	}
}
