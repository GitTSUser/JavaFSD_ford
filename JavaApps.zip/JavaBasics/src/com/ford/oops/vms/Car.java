package com.ford.oops.vms;

public class Car extends AbstractVehicle {

	public Car(String vehicleName) {

		super.vehicleType = vehicleName;
	}

	@Override
	public void move(String from, String to) {

		System.out.println("travelling on car " + from + " - " + to);

	}

}
