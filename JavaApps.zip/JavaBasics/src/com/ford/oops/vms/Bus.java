package com.ford.oops.vms;

public class Bus extends AbstractVehicle {

	public Bus(String vehicleName) {
		super.vehicleType = vehicleName;
	}

	@Override
	public void move(String from, String to) {

		System.out.println("travelling on Bus " + from + " - " + to);

	}

}
