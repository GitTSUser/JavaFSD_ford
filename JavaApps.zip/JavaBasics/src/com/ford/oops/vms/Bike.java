package com.ford.oops.vms;

public class Bike extends AbstractVehicle {

	public Bike(String name) {
		super.vehicleType = name;
		// super(name);
	}

	@Override
	public void move(String from, String to) {

		System.out.println("travelling on bike from " + from + " to " + to);

	}

}
