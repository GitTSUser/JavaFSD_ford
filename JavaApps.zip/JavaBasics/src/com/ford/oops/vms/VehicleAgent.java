package com.ford.oops.vms;

public class VehicleAgent {

	public static IVehicle getVehicle(String vehicleName) {

		if (vehicleName.equals("bike")) {
			return new Bike(vehicleName);
		} else if (vehicleName.equals("car")) {
			return new Car(vehicleName);
		} else if (vehicleName.equals("bus")) {
			return new Bus(vehicleName);
		}

		return null;

	}

}
