package com.ford.oops;

import java.util.Arrays;

class Employee {

	private int id;
	private String name;
	private double salary;
	private String designation;
	private String email;
	private String projects[];
	private static String company = "FORD";

	public Employee() {
	}

	public Employee(int id) {
		this();
		this.id = id;
	}

	public Employee(int id, String name) {
		this(id);
		this.name = name;
	}

	public Employee(int id, String name, double salary) {
		this(id, name);
		this.salary = salary;
	}

	public Employee(int id, String name, double salary, String designation, String email) {
		this(id, name, salary);
		this.designation = designation;
		this.email = email;
	}

	public Employee(int id, String name, double salary, String designation, String email, String projects[]) {
		this(id, name, salary, designation, email);
		this.projects = projects;
	}

	public void printEmployInfo() {
		System.out.println(this.company + " " + this.id + " " + this.name + " " + this.salary + " " + this.designation
				+ " " + this.email + " " + Arrays.toString(this.projects));
	}

	public int getId() {
		return this.id;
	}
	
	public String getName() {
		return this.name;
	}
	public double getSalary() {
		return this.salary;
	}
}

public class AppThree {

	public static void main(String[] args) {

		Employee employee1 = new Employee(1001, "arun");

		employee1.printEmployInfo();

		Employee employee2 = new Employee(1002, "varun", 50000.25);

		employee2.printEmployInfo();

		Employee employee3 = new Employee(1003, "Kumaran", 70000.26, "manager", "kumaran@ford.com");

		employee3.printEmployInfo();

		String projects[] = { "BCMS", "CMS", "HMS" };

		Employee employee4 = new Employee(1004, "chandran", 80000.29, "General Manager", "chandran@ford.com", projects);

		employee4.printEmployInfo();

		Employee employee5 = new Employee();
		employee5.printEmployInfo();

		Employee[] employArr = { employee1, employee2, employee3, employee4, employee5 };

		EmployGradeFinder employGradeFinder = new EmployGradeFinder();

		String[] grades=employGradeFinder.findGrades(employArr);

		System.out.println(Arrays.toString(grades));
		System.out.println("-----Employ grades-----");
		for(int i=0;i<grades.length;i++) {
			System.out.println(employArr[i].getId()+" "+employArr[i].getName()+" "+employArr[i].getSalary()+"  "+grades[i]);
		}

	}
}
