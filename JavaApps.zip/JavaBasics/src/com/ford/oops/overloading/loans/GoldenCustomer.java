package com.ford.oops.overloading.loans;

public class GoldenCustomer extends Customer{
	
	private int goldCount;

	public GoldenCustomer(String name, long phone, int goldCount) {
		super(name, phone);
		this.goldCount = goldCount;
	}

	
	public int getGoldCount() {
		return goldCount;
	}


	public void setGoldCount(int goldCount) {
		this.goldCount = goldCount;
	}


	public void printGoldenCustomerInfo() {

		super.printCustomerInfo();
		System.out.println("golden customer has gold of :" + goldCount+" kgs");
	}

}
