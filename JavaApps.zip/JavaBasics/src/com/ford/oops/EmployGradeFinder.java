package com.ford.oops;

public class EmployGradeFinder {

	public String[] findGrades(Employee[] employees) {

		// logic to find out the grades based on employ salary

		String grades[] = new String[employees.length];

		int i = 0;
		for (Employee employee : employees) {

			if (employee.getSalary() >= 50000 && employee.getSalary() <= 70000) {
				grades[i] = "A";
			} else if (employee.getSalary() > 70000 && employee.getSalary() <= 100000) {
				grades[i] = "B";
			} else if (employee.getSalary() > 100000 && employee.getSalary() <= 150000) {
				grades[i] = "C";
			} else {
				grades[i] = "D";
			}
			i++;

		}

		return grades;

	}

}
