package com.ford.oops.generics;

import java.util.Arrays;
import java.util.List;

public class GenericTester {

	public static double sum(List<? extends Number> numberList) {
		double sum = 0;

		for (Number n : numberList) {
			sum = sum + n.intValue();
		}
		return sum;
	}

	public static void main(String[] args) {

		List<Integer> numList = Arrays.asList(1, 2, 3);

		System.out.println(sum(numList));

		List<Double> numList2 = Arrays.asList(1.1, 2.1, 3.1);

		System.out.println(sum(numList2));

	}
}