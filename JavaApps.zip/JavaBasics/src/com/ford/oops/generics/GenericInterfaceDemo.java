package com.ford.oops.generics;

interface Trainable<T> {
	void train(T t);
}

class Student {
	private int id;
	private String name;
	private String course;

	public Student(int id, String name, String course) {
		this.id = id;
		this.name = name;
		this.course = course;
	}

	public String getName() {
		return this.name;
	}

	public String getCourse() {
		return this.course;
	}
}

class ITStudent extends Student {
	private String programmingLanguage;

	public ITStudent(int id, String name, String course, String programmingLanguage) {
		super(id, name, course);
		this.programmingLanguage = programmingLanguage;
	}

	public String getProgrammingLanguage() {
		return programmingLanguage;
	}

	public void setProgrammingLanguage(String programmingLanguage) {
		this.programmingLanguage = programmingLanguage;
	}

}

class NonITStudent extends Student {
	private String fieldOfStudy;

	public NonITStudent(int id, String name, String course, String fieldOfStudy) {
		super(id, name, course);
		this.fieldOfStudy = fieldOfStudy;
	}

	public String getFieldOfStudy() {
		return this.fieldOfStudy;
	}
}

class Trainer implements Trainable<Student> {
	@Override
	public void train(Student student) {
		System.out.println("Training general student: " + student.getName());
	}
}

class ITTrainer implements Trainable<ITStudent> {
	@Override
	public void train(ITStudent itStudent) {
		// ITTrainer-specific training logic for IT students
		System.out.println("Training IT student: " + itStudent.getName() + " in " + itStudent.getProgrammingLanguage());
	}
}

class NonITTrainer implements Trainable<NonITStudent> {
	@Override
	public void train(NonITStudent nonITStudent) {
		// NonITTrainer-specific training logic for non-IT students
		System.out.println(
				"Training non-IT student: " + nonITStudent.getName() + " in " + nonITStudent.getFieldOfStudy());
	}
}

public class GenericInterfaceDemo {
	public static void main(String[] args) {
		// Creating instances of different types of students
		ITStudent itStudent = new ITStudent(1, "John", "IT", "Java");
		NonITStudent nonITStudent = new NonITStudent(2, "Alice", "History", "Archaeology");

		// Creating instances of trainers
		Trainer generalTrainer = new Trainer();
		ITTrainer itTrainer = new ITTrainer();
		NonITTrainer nonITTrainer = new NonITTrainer();

		// Training different types of students
		generalTrainer.train(itStudent); // Training general student
		itTrainer.train(itStudent); // Training IT student
		nonITTrainer.train(nonITStudent);// Training non-IT student
	}
}