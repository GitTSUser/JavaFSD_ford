package com.ford.oops.generics;

class MyGenericClass<T> {

	private T genericField;

	public MyGenericClass(T genericField) {
		this.genericField = genericField;
	}

	public T getGenericField() {
		return genericField;
	}

	public void setGenericField(T genericField) {
		this.genericField = genericField;
	}

	// Generic method that takes an argument of any type and prints it
	public <E> void printElement(E element) {
		System.out.println("Element: " + element);
	}

	// Another generic method that compares two elements of the same type
	public <E extends Comparable<E>> int compareElements(E element1, E element2) {
		return element1.compareTo(element2);
	}

}

public class GenericAppThree {

	public static void main(String[] args) {
		// Example usage of the generic class
		MyGenericClass<String> stringGenericClass = new MyGenericClass<>("Hello, Generics!");
		System.out.println("Generic Field: " + stringGenericClass.getGenericField());

		stringGenericClass.printElement("This is a generic method.");

		MyGenericClass<Integer> integerGenericClass = new MyGenericClass<>(42);
		System.out.println("Generic Field: " + integerGenericClass.getGenericField());

		integerGenericClass.printElement(123);

		// Example usage of the generic method for comparison
		int result = integerGenericClass.compareElements(5, 10);
		System.out.println("Comparison Result: " + result);
	}
}
