package com.ford.oops.generics;

class MyGeneric<T> {

	private T t;

	public MyGeneric(T t) {
		this.t = t;
	}

	public T  getValue() {
		return  this.t;
	}

}

class Product {

	private int id;
	private String name;
	private double price;

	public Product(int id, String name, double price) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", price=" + price + "]";
	}
	
	

}

public class GenericAppOne {

	public static void main(String[] args) {

		MyGeneric<Integer> intObj = new MyGeneric<Integer>(10);

		System.out.println("value is:" + intObj.getValue());

		MyGeneric<String> stringObj = new MyGeneric<String>("SuryaKiranKumar");
		System.out.println("value is:" + stringObj.getValue());

		Product product = new Product(1001, "fan", 2500.25);
		
		MyGeneric<Product> productObj=new MyGeneric<Product>(product);
		
		System.out.println("value is:"+productObj.getValue());
		
		
	}
}
