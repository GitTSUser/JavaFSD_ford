package com.ford.oops.generics;

import java.util.Arrays;
import java.util.List;

public class GenericAppTwo {

	public static <T> void swap(T[] arr, int one, int two) {

		T temp = arr[one];

		arr[one] = arr[two];

		arr[two] = temp;

	}

	public static <T extends Comparable<T>> T max(List<T> list) {

		T ele = list.get(0);

		for (T temp : list) {

			if (temp.compareTo(ele) > 0) {
				ele = temp;
			}
		}

		return ele;
	}

	public static void main(String[] args) {

		String[] names = { "Alice", "Bob", "Charlie" };
		swap(names, 0, 2);
		System.out.println(Arrays.toString(names));

		List<Integer> numbers = Arrays.asList(3, 5, 1, 7);
		Integer maxNumber = max(numbers);
		System.out.println(maxNumber);
	}
}