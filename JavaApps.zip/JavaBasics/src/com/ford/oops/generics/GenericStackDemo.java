package com.ford.oops.generics;

class GenericStack<T> {

	private int size;
	private Object elements[];

	public GenericStack(int capacity) {
		this.size = 0;
		elements = new Object[capacity];
	}

	public void push(T ele) {
		if (size < elements.length) {
			elements[size] = ele;
			size++;
			System.out.println(ele+" pushed into stack");
		} else {
			System.out.println("Stack is full");
		}
	}

	public T pop() {
		if (size > 0) {

			size--;
			return (T) elements[size];
		} else {
			System.out.println("Stack is empty");
		}

		return null;
	}

	public int size() {
		return this.size;
	}
	
	public void printStack() {
		
		for(int i=size-1;i>=0;i--) {
			System.out.println(elements[i]);
		}
		
	}

}

public class GenericStackDemo {

	public static void main(String[] args) {
		
		
		GenericStack<Integer> numStack=new GenericStack<>(3);
		numStack.push(10);
		numStack.push(20);
		numStack.push(30);
		numStack.push(40);
		
		numStack.printStack();
		System.out.println("popped element:"+numStack.pop());
		System.out.println("popped element:"+numStack.pop());

		numStack.printStack();
		
		
		GenericStack<String> lappyStack=new GenericStack<>(3);
		lappyStack.push("Lenovo");
		lappyStack.push("Dell");
		lappyStack.push("Acer");
		lappyStack.push("Samsung");
		
		lappyStack.printStack();
		
		
		
		
	}
}
