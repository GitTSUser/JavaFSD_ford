package com.ford.oops.has;

public class SpeedoMeter {

	private int kilometerTravelled;

	public SpeedoMeter(int kilometerTravelled) {
		this.kilometerTravelled = kilometerTravelled;
	}

	public int getKilometerTravelled() {
		return kilometerTravelled;
	}

	public void setKilometerTravelled(int kilometerTravelled) {
		this.kilometerTravelled = kilometerTravelled;
	}

}
