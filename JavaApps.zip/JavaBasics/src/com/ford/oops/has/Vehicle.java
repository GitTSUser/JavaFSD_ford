package com.ford.oops.has;

public class Vehicle {

	private String name;
	private int noOfSeats;
	private SpeedoMeter speedoMeter;
	private String color;

	public Vehicle(String name, int noOfSeats, SpeedoMeter speedoMeter, String color) {
		super();
		this.name = name;
		this.noOfSeats = noOfSeats;
		this.speedoMeter = speedoMeter;
		this.color = color;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getNoOfSeats() {
		return noOfSeats;
	}

	public void setNoOfSeats(int noOfSeats) {
		this.noOfSeats = noOfSeats;
	}

	public SpeedoMeter getSpeedoMeter() {
		return speedoMeter;
	}

	public void setSpeedoMeter(SpeedoMeter speedoMeter) {
		this.speedoMeter = speedoMeter;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}
	
	

}
