package com.ford.oops.has;

public class Main {

	public static void main(String[] args) {

		SpeedoMeter speedoMeter = new SpeedoMeter(45000);

		Vehicle vehicle = new Vehicle("Honda-Activa", 2, speedoMeter, "maroon");

		
		System.out.println(vehicle.getName()+"  "+vehicle.getNoOfSeats()+"  "+vehicle.getColor());
		
		/*SpeedoMeter sp=vehicle.getSpeedoMeter();
		
		System.out.println(sp.getKilometerTravelled());
	*/	
	
		System.out.println("No.of kilometers travelled:"+vehicle.getSpeedoMeter().getKilometerTravelled());
		
		
	}
}
