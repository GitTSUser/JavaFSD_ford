package com.ford.oops.inheritance;

public class CardController {
	
	public static void main(String[] args) {
		
		
		CreditCard card=new CreditCard(1234,"VISA","diners credit card","12-12-2024", 0, 0, null, null, 0);
		
		card.getCardInfo();
		
	}

}
