package com.ford.oops.inheritance;

public class CreditCard extends Card {

	private double creditLimit;
	private int rewardPoints;
	private String cardHolderName;
	private double purchases[];
	private int billingDays;

	public CreditCard(long cardNum, String cardType, String cardName, String cardExpiryDate, double creditLimit,
			int rewardPoints, String cardHolderName, double[] purchases, int billingDays) {
		super(cardNum, cardType, cardName, cardExpiryDate);
		this.creditLimit = creditLimit;
		this.rewardPoints = rewardPoints;
		this.cardHolderName = cardHolderName;
		this.purchases = purchases;
		this.billingDays = billingDays;
	}	
	
	
	
}