package com.ford.oops.inheritance.callcenter;

public class Customer {

	private static long genId = 12345678;
	private long id;
	private String name;
	private String membership;
	private long phone;

	public Customer(String name, String membership, long phone) {
		genId = genId + 1;
		this.id = genId;
		this.name = name;
		this.membership = membership;
		this.phone = phone;
	}

	public void setId(long id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setMembership(String membership) {
		this.membership = membership;
	}

	public void setPhone(long phone) {
		this.phone = phone;
	}

	public long getId() {
		return this.id;
	}

	public String getName() {
		return name;
	}

	public String getMembership() {
		return this.membership;
	}

	public long getPhone() {
		return this.phone;
	}

	public void printCustomerInfo() {
		System.out.println(this.id + " " + this.name + " " + this.membership + " " + this.phone);
	}

}
