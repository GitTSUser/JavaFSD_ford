package com.ford.oops.inheritance.callcenter;

public class CallCenter {

	private static void pickUpCall() {
		System.out.println("Started serving customer");
	}

	private static void allotTime(int time) {
		System.out.println("Alloted time " + time + " min for customer");
	}

	private static void hangCall() {
		System.out.println("Service over to customer");
	}

	public static void makeCallToCallCenter(Customer customer) {

		pickUpCall();
		if (customer.getMembership().equals("premium")) {
			allotTime(15);
		} else if (customer.getMembership().equals("golden")) {
			allotTime(10);
		} else {
			allotTime(5);
		}
		hangCall();
	}

}
