import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private userCred={ email:"",pwd:""};
  constructor() { }

  saveUserInfo(userInfo:any):boolean{
  //  this.userCred.email=userInfo.value.email;
   // this.userCred.pwd=userInfo.value.pwd;
   localStorage.setItem("email",userInfo.value.email);
   localStorage.setItem("pwd",userInfo.value.pwd);
    return true;
  }

  verifyUserInfo(userInfo:any):boolean{
   /* if(this.userCred.email===userInfo.value.email && this.userCred.pwd===userInfo.value.pwd){
      return true;
    }*/

    if(localStorage.getItem("email")===userInfo.value.email && localStorage.getItem("pwd")===userInfo.value.pwd){
      return true;
    }

    return false;
  }


}
