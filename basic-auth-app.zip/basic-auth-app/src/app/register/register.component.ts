import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {


  constructor(private router:Router,private authService:AuthService) { }

  ngOnInit(): void {
  }
  onSubmission(myForm:any){
    if(this.authService.saveUserInfo(myForm)){
      window.alert("Data saved Successfully")
      this.router.navigate(["login"])
      }else{
        window.alert("Data saving failed")
    }
  }
}
