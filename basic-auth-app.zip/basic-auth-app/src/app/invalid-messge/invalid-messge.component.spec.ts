import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InvalidMessgeComponent } from './invalid-messge.component';

describe('InvalidMessgeComponent', () => {
  let component: InvalidMessgeComponent;
  let fixture: ComponentFixture<InvalidMessgeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InvalidMessgeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InvalidMessgeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
