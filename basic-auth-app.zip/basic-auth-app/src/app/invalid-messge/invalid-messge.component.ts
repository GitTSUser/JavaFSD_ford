import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-invalid-messge',
  templateUrl: './invalid-messge.component.html',
  styleUrls: ['./invalid-messge.component.css']
})
export class InvalidMessgeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
