import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'basic-auth-app';

  constructor(private router:Router){}
  handleLogout(){

      localStorage.removeItem("email");
      localStorage.removeItem("pwd");
      this.router.navigate(["home"]);
      return;

  }
}
