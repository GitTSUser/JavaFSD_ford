import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template:`
  <p>{{title}}</p>
  <button (click)="doSomething()" class="btnClass" [disabled]="isClicked">{{btnText}}</button>
  `,
    styles:[
      `
    .btnClass{
      background-color:blue;
    }
   `
  ]
})
export class AppComponent {
  title = 'my-testing-app';

  btnText="ClickMe";
  isClicked:boolean=false;

  doSomething(){
    this.btnText="ClickedMe";
    this.isClicked=true;
  }

}
