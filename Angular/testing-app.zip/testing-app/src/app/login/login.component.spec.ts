import { ComponentFixture, TestBed } from '@angular/core/testing';
import { LoginComponent } from './login.component';
import { ReactiveFormsModule } from '@angular/forms'; // Import ReactiveFormsModule
import { By } from '@angular/platform-browser';

describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LoginComponent ],
      imports: [ ReactiveFormsModule ] // Add ReactiveFormsModule to imports
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should have form fields username and password', () => {
    let unameControl = fixture.debugElement.query(By.css('input[name=uname]'));
    let pwdControl = fixture.debugElement.query(By.css('input[name=upwd]'));
    let submitBtn=fixture.debugElement.query(By.css('input[type=submit]'));    

    unameControl.nativeElement.value = 'arun@yahoo.com';
    pwdControl.nativeElement.value = 'arun@123';

    unameControl.nativeElement.dispatchEvent(new Event('input')); //simulate events to mimic user interactions
    pwdControl.nativeElement.dispatchEvent(new Event('input'));//simulate events to mimic user interactions
    submitBtn.nativeElement.click(); //simulate click event on login button
    fixture.detectChanges();
  

    expect(component.loginForm.value.uname).toEqual('arun@yahoo.com');
    expect(component.loginForm.value.upwd).toEqual('arun@123');
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
