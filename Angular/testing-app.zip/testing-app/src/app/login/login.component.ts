import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-login',
  template: `
    <div>
      <h1>{{ loginTitle }}</h1>
      <form [formGroup]="loginForm" (ngSubmit)="submitForm()">
        <input type="text" id="uname" name="uname" formControlName="uname" placeholder="Username"/>
        <br>
        <input type="password" id="upwd" name="upwd" formControlName="upwd" placeholder="Password"/>
        <br><br>
        <input type="submit" name="submit" value="Login"/>
        &nbsp;&nbsp;
        <input type="reset" name="clear" value="Clear"/>  
      </form>
    </div>
  `,
  styles: []
})
export class LoginComponent implements OnInit {
  loginTitle: string = "Login Here";
  loginForm: FormGroup;

  constructor(private formBuilder: FormBuilder) {
    this.loginForm = this.formBuilder.group({
      uname: ['', [Validators.required, Validators.nullValidator]],
      upwd: ['', [Validators.required]]
    });
  }

  ngOnInit(): void {
    // No need for anything here, as it's empty.
  }

  submitForm() {
    console.log(this.loginForm);
  }
}
