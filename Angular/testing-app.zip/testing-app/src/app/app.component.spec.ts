import { TestBed, ComponentFixture } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppComponent } from './app.component';
import { By } from '@angular/platform-browser';

describe('AppComponent', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        RouterTestingModule
      ],
      declarations: [
        AppComponent
      ],
    }).compileComponents();
  });


  xit('should render the title given now',()=>{
    const fixture=TestBed.createComponent(AppComponent);
    fixture.detectChanges();
    const element=fixture.nativeElement as HTMLElement;
    expect(element.textContent).toBe("my-testing-app")
  })


  it('should render the button with text ClickMe',()=>{
    const fixture=TestBed.createComponent(AppComponent);
    const debugEle=fixture.debugElement; //will give debug element on fixture
    const comp=fixture.componentInstance; //will give instance of AppComponent
    comp.isClicked=false; //set properties like 
    comp.btnText="ClickMe";
    fixture.detectChanges();
    expect(comp.isClicked).toBeFalse();
    expect(comp.btnText).toBe("ClickMe");
  })

  it('should render the button with text ClickedMe',()=>{

    const fixture=TestBed.createComponent(AppComponent);
    const debugEle=fixture.debugElement; //will give debug element on fixture
    const comp=fixture.componentInstance; //will give instance of AppComponent
    comp.isClicked=true; //set properties like 
    comp.btnText="ClickedMe";
   
    fixture.detectChanges();
    expect(comp.isClicked).toBeTrue();
    expect(comp.btnText).toBe("ClickedMe");
  })


  xit('should create the app', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app).toBeTruthy();
  });

  xit(`should have as title 'testing-app'`, () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app.title).toEqual('testing-app');
  });

  xit('should render title', () => {
    const fixture = TestBed.createComponent(AppComponent);
    fixture.detectChanges();
    const compiled = fixture.nativeElement as HTMLElement;
    expect(compiled.querySelector('.content span')?.textContent).toContain('testing-app app is running!');
  });
});
