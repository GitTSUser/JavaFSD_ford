import { TestBed } from '@angular/core/testing';
import { CalcService } from './calc.service';
import { OperaService } from './opera.service';
import { provideRoutes } from '@angular/router';
import { AppComponent } from '../app.component';

xdescribe('CalcService', () => {
  let opera: OperaService;
  let calc: CalcService;

  beforeEach(() => {
    //opera=jasmine.createSpyObj("OperaService",["performSum","performMultiply"]);
    TestBed.configureTestingModule({
      declarations:[AppComponent], 
      imports:[],
      providers: [CalcService, OperaService],
    });
    opera = TestBed.inject(OperaService);
    calc = TestBed.inject(CalcService);
  });

  it('should perform addition', () => {
    //let opera=new OperaService();
    //let calc = new CalcService(opera);

    let result = calc.add(10, 20);
    expect(result).toBe(30);
  });

  it('should perform multiplication', () => {
    // let opera=new OperaService();
    // let calc=new CalcService(opera);

    let result = calc.multiply(20, 30);
    expect(result).toBe(600);
  });

  it('should perform sum with mockspy', () => {
    let opera = jasmine.createSpyObj('OperaService', ['performSum']); //creation of mock
    opera.performSum.and.returnValue(50); //add behavior to performSum
    let calc = new CalcService(opera);

    let result = calc.add(20, 30);

    expect(result).toBe(50);

    expect(opera.performSum).toHaveBeenCalledWith(20, 30); //verify the call happens or not
  });
});
