import { Injectable } from '@angular/core';
import { OperaService } from './opera.service';

@Injectable({
  providedIn: 'root',
})
export class CalcService {
  constructor(private opService: OperaService) {}

  add(x: number, y: number): number {
    console.log('CalcService.add() called');
    let result = this.opService.performSum(x, y);
    return result;
  }

  multiply(x: number, y: number): number {
    console.log('CalcService.multiply() called');
    let result = this.opService.performMultiply(x, y);
    return result;
  }
}
