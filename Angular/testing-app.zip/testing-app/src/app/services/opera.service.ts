import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class OperaService {
  constructor() {
    console.log("OperaService::constructor() called")
  }

  performSum(a: number, b: number): number {
    console.log("OperaService::performSum() called")
    return a + b;
  }

  performMultiply(a: number, b: number): number {
    console.log("OperaService::performMultiply() called")
    return a * b;
  }
}
