import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dish',
  templateUrl: './dish.component.html',
  styleUrls: ['./dish.component.css'],
})
export class DishComponent {
  title: string = 'Hotel Ashoka';

  dishes: string[] = ['Idly', 'Wada', 'Dosa', 'Puri'];

  dishImages: string[] = [
    'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRV23qQhl2IkKTi7DGLZ3buna_hPtSrL470CuruWRSq8A&s',
    'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRb-CyCWSXEfAa1cjRiTSn-kglldCDWQwZK9QEnIb88rg&s',
    'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSQBGtEjBUzHzewOLoXTZgMFbN0M2bOQya46x2Biv2eag&s',
    'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ-tw0Azt0TJibIo1Xtfolehxbzkj1q5tNioHhKlVjW8w&s',
  ];

  nums: number[] = [1, 2, 3, 4, 5, 6, 7, 8];

  selectedDish = '';
  displayDishInfo(eventObj: any) {
    this.selectedDish = this.dishImages[eventObj.target.value];
  }
}
