import { Directive, ElementRef, Host, HostBinding, HostListener } from '@angular/core';

@Directive({
  selector: '[appCustom]'
})
export class CustomDirective {

  @HostBinding('style.color')
  color:string | undefined='red';

  constructor(private element:ElementRef) { }

  @HostListener('mouseover')
  onMouseOverDoSomething(){

    this.element.nativeElement.style.backgroundColor='yellow';
  }

  @HostListener("mouseleave")
  onMouseLeaveDoSomething(){

    this.element.nativeElement.style.backgroundColor='white';
    this.element.nativeElement.textContent="Hello How r you?";

  }

}
