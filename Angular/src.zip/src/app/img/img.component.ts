import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-img',
  templateUrl: './img.component.html',
  styleUrls: ['./img.component.css']
})
export class ImgComponent {

    myImg="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSY3HYfNLW_rK3hS0ncx_-YJMPlyh64Njt7F5xVjS7Gig&s";

    myImgWidth="150";
    myImgHeight="150";

     imgStatus:boolean=false; //image is visible

     myImgDisplayStatus="none";

    doSomething(){
      if(this.imgStatus==false){
      this.myImgDisplayStatus="block";
      this.imgStatus=true;
      }else{
        this.myImgDisplayStatus="none";
        this.imgStatus=false;
      }
      //alert("clicked button");
    }

}
