import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-child',
/*  templateUrl: './child.component.html',*/

template:`
<div style="background-color: lightpink;">
<h2> Child Area</h2>

<p>Message from Parent:{{msgFromParent}}</p>

<button (click)="sendGift()">Parent-ClickMe</button>

</div>
`,

  styleUrls: ['./child.component.css']
})
export class ChildComponent {

  @Input()
  msgFromParent:string | undefined;

  
  @Output()
  fireEvent=new EventEmitter();

   msgToParent="Welcome to Chennai Parent!";

   sendGift(){

    return this.fireEvent.emit(this.msgToParent);

   }


}
