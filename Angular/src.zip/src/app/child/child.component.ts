import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-child',
/*  templateUrl: './child.component.html',*/

template:`
<div style="background-color: lightpink;">
<h2> Child Area</h2>

<p>{{msgFromParent}}</p>
</div>
`,

  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {

  @Input()
  msgFromParent:string | undefined;
  
  constructor() { }

  ngOnInit(): void {
  }

}
