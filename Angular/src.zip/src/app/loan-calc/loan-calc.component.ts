import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loan-calc',
  templateUrl: './loan-calc.component.html',
  styleUrls: ['./loan-calc.component.css']
})
export class LoanCalcComponent implements OnInit {
  amount:number;
  roi:number;
  year:number;

  constructor() {
    this.amount=0;
    this.year=0;
    this.roi=0.0;
   }


  ngOnInit(): void {
  }

}
