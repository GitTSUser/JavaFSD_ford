import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent {

  headings=["ProductId","Name","Price"];

  products=[
    {id:1001,
    name:"fan",
     price:15000.25},
     {id:1002,
      name:"mouse",
       price:400.25},
       {id:1003,
        name:"mobile",
         price:25000.25}
  ]


}
