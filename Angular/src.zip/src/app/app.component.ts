import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
/*  templateUrl: './app.component.html',*/

template:`
<div style="border:1px solid blue;">
<p>Parent Area</p>
<app-child [msgFromParent]="msgToChild"></app-child>
</div>
`,

  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app-four';

  uname:string="";
  upwd:string="";

 msgToChild:string="Hello Kid ! How are you?";
}
