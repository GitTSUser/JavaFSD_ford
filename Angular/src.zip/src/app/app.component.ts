import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  /*  templateUrl: './app.component.html',*/

  template: `
    <div style="border:1px solid blue;">
      <!--<p>Parent Area</p>
<app-child [msgFromParent]="msgToChild" (fireEvent)="msgFromChild=$event"></app-child>

<p>Message from Child : {{msgFromChild}}</p>

<hr>
<p style="padding-left:20px;">
  <li *ngFor="let color of colors;let i=index" 
        [ngStyle]="{backgroundColor:getBgColor(i),color:'white'}">{{color}}</li>
</p>
-->

      <p
        *ngFor="let product of products; let i = index"
        [ngClass]="{ evenProduct: i % 2 == 0, oddProduct: i % 2 != 0 }"
      >
        {{ product.id }} {{ product.name }} {{ product.price }}
      </p>

      <p appCustom>I am applied appCustom Directive</p>

      <p appCustom>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloribus earum
        deleniti asperiores deserunt suscipit, in quas, aliquam nobis voluptates
        sequi voluptas ad placeat accusantium temporibus id odit, ea minus cum.
      </p>
    </div>
  `,
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'app-four';
  uname: string = '';
  upwd: string = '';

  products = [
    {
      id: 1001,
      name: 'fan',
      price: 2500.25,
    },
    {
      id: 1002,
      name: 'chair',
      price: 4500.25,
    },
    {
      id: 1003,
      name: 'lappy',
      price: 25000.25,
    },
    {
      id: 1004,
      name: 'mobile',
      price: 65000.25,
    },
    {
      id: 1005,
      name: 'smartphone',
      price: 65000.25,
    },
    {
      id: 1006,
      name: 'i-phone',
      price: 65000.25,
    },
  ];

  colors = ['blue', 'white', 'green', 'red', 'yellow'];

  msgToChild: string = 'Hello Kid ! How are you?';
  msgFromChild: string | undefined;

  getBgColor(i: number) {
    return this.colors[i];
  }
}
