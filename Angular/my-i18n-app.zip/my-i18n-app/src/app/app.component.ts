import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template:`
    <h1 i18n="main header|Friendly welcome message">I love People of My Country</h1>
      `,
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'my-i18n-app';
}
