/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { UserItemComponent } from './user-item.component';

describe('Component: UserItem', () => {
  it('should create an instance', () => {
    let component = new UserItemComponent();
    expect(component).toBeTruthy();
  });
});
