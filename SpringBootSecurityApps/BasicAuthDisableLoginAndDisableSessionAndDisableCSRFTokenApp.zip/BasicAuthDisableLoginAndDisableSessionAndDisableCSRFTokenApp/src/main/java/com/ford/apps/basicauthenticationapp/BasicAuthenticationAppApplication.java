package com.ford.apps.basicauthenticationapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BasicAuthenticationAppApplication {

    public static void main(String[] args) {
        SpringApplication.run(BasicAuthenticationAppApplication.class, args);
    }

}
