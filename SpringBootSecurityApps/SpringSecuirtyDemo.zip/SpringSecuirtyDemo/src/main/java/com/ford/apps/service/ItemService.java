package com.ford.apps.service;

import  com.ford.apps.entity.Item;
import java.util.List;
public interface ItemService {
    public Item addItem(Item item);
    public Item getItem(long itemNo);
    public List<Item> getAllItem();
    public Item updateItem(Item item);
    public boolean deleteItem(long itemNo);
}
