package com.ford.apps.controller;

import com.ford.apps.entity.Item;
import com.ford.apps.service.ItemService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@Slf4j
public class ItemController {

    @Autowired
    private ItemService itemService;

    @PostMapping("/items")
    public Item saveItemInfo(@RequestBody Item item){
      log.info("ItemController::saveItemInfo(Item item) method start");

      Item savedItem=itemService.addItem(item);
        log.info("ItemController::saveItemInfo(Item item) method ends");
      return savedItem;
    }

    @PutMapping("/items")
    public Item updateItemInfo(@RequestBody Item item){
        log.info("ItemController::updateItemInfo(Item item) method start");

        Item updatedItem=itemService.updateItem(item);
        log.info("ItemController::updateItemInfo(Item item) method ends");
        return updatedItem;
    }

    @GetMapping("/items")
    public List<Item> getAllItemInfo(){
        log.info("ItemController::getAllItemInfo() method start");

        List<Item> itemList=itemService.getAllItem();
        log.info("ItemController::getAllItemInfo() method ends");
        return itemList;
    }

    @GetMapping("/items/{itemNo}")
    public Item getItemInfo(@PathVariable("itemNo")Long itemNo){
        log.info("ItemController:: getItemInfo(Long itemNo) method start");

        Item item=itemService.getItem(itemNo);
        log.info("ItemController:: getItemInfo(Long itemNo) method ends");
        return item;
    }

    @DeleteMapping("/items/{itemNo}")
    public String deleteItemInfo(@PathVariable("itemNo")Long itemNo){
        log.info("ItemController:: deleteItemInfo(Long itemNo) method start");

        boolean deleteStatus=itemService.deleteItem(itemNo);

        log.info("ItemController:: deleteItemInfo(Long itemNo) method ends");
        return " Item deleted successfully!";
    }

}
