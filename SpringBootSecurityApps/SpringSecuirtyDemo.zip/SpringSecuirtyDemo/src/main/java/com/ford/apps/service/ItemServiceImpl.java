package com.ford.apps.service;

import com.ford.apps.entity.Item;
import com.ford.apps.repository.ItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ItemServiceImpl implements ItemService {

    @Autowired
    private ItemRepository itemRepository;

    @Override
    public Item addItem(Item item) {
        return itemRepository.save(item);
    }

    @Override
    public Item getItem(long itemNo) {
        return itemRepository.findById(itemNo).get();
    }

    @Override
    public List<Item> getAllItem() {
        return itemRepository.findAll();
    }

    @Override
    public Item updateItem(Item item) {
        Item itemToUpdate = getItem(item.getItemNo());
        itemToUpdate.setName(item.getName());
        itemToUpdate.setPrice(item.getPrice());
        itemToUpdate.setQuantity(item.getQuantity());

        itemRepository.save(itemToUpdate);
        return itemToUpdate;
    }

    @Override
    public boolean deleteItem(long itemNo) {
        itemRepository.deleteById(itemNo);
        return true;
    }
}
