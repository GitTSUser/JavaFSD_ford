package com.ford.apps.service;

import com.ford.apps.entity.Product;

import java.util.List;



public interface IProductService {

	public Product saveProduct(Product product);

	public Product getProduct(Integer id);

	public List<Product> getAllProducts();
}
