package com.ford.apps;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RoleBasedSecuredAppApplicationTests {

    @Test
    void contextLoads() {
    }

}
