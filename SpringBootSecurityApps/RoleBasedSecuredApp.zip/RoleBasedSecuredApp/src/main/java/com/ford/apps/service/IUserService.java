package com.ford.apps.service;

import com.ford.apps.entity.Product;
import com.ford.apps.entity.User;

import javax.swing.*;
import java.util.List;

public interface IUserService {

    public User addUser(User user);
    public boolean deleteUser(Long id);
    public User getUserById(Long id);
    public List<User> allUser();


    public Product addProduct(Product product);
    public boolean deleteProduct(Long id);
    public Product getProductById(Long id);
    public List<Product> allProduct();


}
