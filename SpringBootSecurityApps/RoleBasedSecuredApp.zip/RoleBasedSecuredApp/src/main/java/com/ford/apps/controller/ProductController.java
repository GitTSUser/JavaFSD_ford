package com.ford.apps.controller;

import com.ford.apps.entity.Product;
import com.ford.apps.entity.User;
import com.ford.apps.repository.IUserRepository;
import com.ford.apps.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/products")
@Slf4j
public class ProductController {

    @Autowired
    private UserService userService;



    @GetMapping
    public List<Product> getAllProducts() {
        log.info("getAllProducts method called");
        return userService.allProduct();
    }


    @DeleteMapping("/{id}")
    public boolean deleteProductById(@PathVariable Long id) {
        userService.getProductById(id);
        return true;
    }

    @PostMapping
    public Product addProduct(@RequestBody Product product) {
        log.info("addProdcut(username,product) method begins");
        userService.addProduct(product);
        log.info("addProdcut(username,product) method ends");
        return product;
    }

    @PostMapping("/addUser")
    public User addUser(@RequestBody User user) {
        return userService.addUser(user);
    }
}