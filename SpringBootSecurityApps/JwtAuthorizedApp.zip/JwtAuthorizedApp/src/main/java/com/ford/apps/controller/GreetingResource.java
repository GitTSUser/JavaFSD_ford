package com.ford.apps.controller;

import com.ford.apps.entity.AuthRequest;
import com.ford.apps.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.*;

@RestController
//@RequestMapping("/api")
public class GreetingResource {

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private AuthenticationManager authenticationManager;

    @GetMapping("/wish")
    public String wish() {
        return "Welcome to JwtAuth App";
    }

    @PostMapping("/authenticate")
    public String generateToken(@RequestBody AuthRequest authRequest) {

        try {
            UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(authRequest.getUsername(), authRequest.getPassword());
            authenticationManager.authenticate(usernamePasswordAuthenticationToken);
        } catch (UsernameNotFoundException usernameNotFoundException) {
            throw usernameNotFoundException;
        }
        return jwtUtil.generateToken(authRequest.getUsername());
    }
}
