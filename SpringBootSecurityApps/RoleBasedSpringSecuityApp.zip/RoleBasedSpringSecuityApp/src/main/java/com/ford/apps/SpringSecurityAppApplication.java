package com.ford.apps;

import com.ford.apps.security.entity.Role;
import com.ford.apps.security.entity.User;
import com.ford.apps.security.repository.IUserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.ArrayList;
import java.util.List;

@SpringBootApplication
public class SpringSecurityAppApplication implements CommandLineRunner {

    @Autowired
    private IUserRepository userRepository;

    public static void main(String[] args) {
        SpringApplication.run(SpringSecurityAppApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {

          /*  Role role1=new Role(100L,"ADMIN");
            Role role2=new Role(200L,"SUPER_ADMIN");

            List<Role> roleList=new ArrayList<>();
            roleList.add(role1);
            roleList.add(role2);


            User user1=new User(1234,"arun","arun123",roleList);

            userRepository.save(user1);*/

        System.out.println("user details added in db");

  }
}
