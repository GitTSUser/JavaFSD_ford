package com.ford.apps.controller;

import com.ford.apps.entity.Product;
import com.ford.apps.security.entity.Role;
import com.ford.apps.security.entity.User;
import com.ford.apps.security.repository.IRoleRepository;
import com.ford.apps.security.repository.IUserRepository;
import com.ford.apps.service.IProductService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@Slf4j
@RequestMapping("/api")
public class ProductController {

    @Autowired
    private IProductService productService;
    @Autowired
    private IUserRepository userRepository;

    @Autowired
    private IRoleRepository roleRepository;

    @PostMapping("/products")
    public Product addProduct(@RequestBody Product product) {
        log.info("got product to add is:{}", product);
        return productService.saveProduct(product);
    }

    @PutMapping("/products")
    public Product updateProduct(@RequestBody Product product) {
        log.info("got product for update is:{}", product);
        return productService.saveProduct(product);
    }


    @GetMapping("/products/{id}")
    public Product retrieveProduct(@PathVariable("id") Integer productId) {

        return productService.getProduct(productId);
    }

    @GetMapping("/products")
    public List<Product> retrieveAllProducts() {
        return productService.getAllProducts();
    }

    @PostMapping("/user")
    public User saveUser(@RequestBody User user) {
        System.out.println("user to be added is:"+user);
        return userRepository.save(user);
    }

    @PostMapping("/role")
    public Role saveRole(@RequestBody Role role) {
        return roleRepository.save(role);
    }
}