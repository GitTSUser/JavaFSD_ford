package com.ford.apps.basicauthenticationapp.config;

import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class GlobalCorsConfiguration implements WebMvcConfigurer {


    @Override
    public void addCorsMappings(CorsRegistry registry) {
        // .allowedOrigins("http://localhost:4200", "http://localhost:3900")
        registry.addMapping("/**")
                .allowedOrigins("*") //currently accepts all origins
                .allowedMethods("GET", "POST", "PUT", "DELETE")
                .allowedHeaders("*")
                .exposedHeaders("Authorization")
                .allowCredentials(true)
                .maxAge(3600);
        //WebMvcConfigurer.super.addCorsMappings(registry);
    }
}
