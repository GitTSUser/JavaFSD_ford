package com.ford.apps.basicauthenticationapp.resource;

import com.ford.apps.basicauthenticationapp.model.Product;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api")
@Slf4j
public class ProductResource {
    private static List<Product> productList = new ArrayList<>();

    static {
        Product p1=new Product(1,"Television",25000.25);
        Product p2=new Product(2,"Chair",5000.25);
        Product p3=new Product(3,"Laptop",45000.25);
        Product p4=new Product(4,"Mouse",500.25);
        productList.add(p1);
        productList.add(p2);
        productList.add(p3);
        productList.add(p4);
    }

    @GetMapping("/products")
    public List<Product> getAllProducts() {
        log.info("getAllProducts method called");
        return productList;
    }


    /*@GetMapping("/products/{username}")
    public Product getProductListForUser(@PathVariable("username") String username) {
        log.info("getProductListForUser(username) method called");
        return productList.get(0);
    }


    @PostMapping("/products/{username}")
    public Product addProduct(@PathVariable("username") String username,@RequestBody Product product) {
    log.info("addProdcut(username,product) method begins");
        productList.add(product);
        log.info("addProdcut(username,product) method ends");

        return  product;
    }*/
}
