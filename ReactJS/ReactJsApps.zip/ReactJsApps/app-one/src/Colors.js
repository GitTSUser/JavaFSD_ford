
import './Colors.css';

function Colors() {
  let myColors = ["blue", "yellow", "orange", "green", "red"];


 const handleClick= ()=>{
    alert("You clicked Button");
  }

  return (
    <div className="heading">
      <h1 style={{textAlign:'center',color:'magenta'}}>Colors You Created</h1>
      <ul>
        {myColors.map((color, idx) => {
          return <li key={idx} style={{listStyle:'none',backgroundColor:color,textAlign:'center'}}>{color}</li>;
        })}
      </ul>
        
      <button onClick={handleClick}>ClickMe</button>
    </div>
  );
}

export default Colors;