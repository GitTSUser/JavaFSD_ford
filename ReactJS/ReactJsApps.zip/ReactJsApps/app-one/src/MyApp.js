import "./MyApp.css";

function MyApp() {
  const name = "KiranKumar";

  const emp = { id: 1001, name: "SharanKumar", salary: 55000.25 };

  const generateEmail = (name) => {
    let emailCode = Math.random() * 123405;
    return name + emailCode + "@yahoo.com";
  };
  
  return (
    <div>
      <h2>Welcome to MyApp Component</h2>

      <p>
        Welcome to <span style={{ color: "red" }}>{name}</span> for React.js
        programming.
      </p>

      <p>
        Employ Id: {emp.id} , Name: {emp.name} and salary is:{emp.salary}
      </p>

      <p>
        Your Email id is:{" "}
        <span style={{ color: "blue" }}>{generateEmail(emp.name)}</span>
      </p>
    </div>
  );
}

export default MyApp;
