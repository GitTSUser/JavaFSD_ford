//program to demonstrate user state management in class component
import { Component } from "react";

class UserInfo extends Component {
  constructor(props) {
    super(props);
    this.state = {
      user: {
        id: 1001,
        name: "arunkumar",
        email: "arun@yahoo.com",
        phone: 9988553333,
      },
    };
  }
  handleChange=()=>{
    let modifiedUserInfo={...this.state.user, email:"varun@rediffmail.com"}
    this.setState({user:modifiedUserInfo});
  }

  render() {
    return (
      <div style={{backgroundColor:'lightblue'}}>
        <h2>UserInfo</h2>
        <p>{this.state.user.id} {" "} {this.state.user.name} {" "} <span style={{color:'red'}}>{this.state.user.email}</span> {" "} {this.state.user.phone}</p>
            <button onClick={this.handleChange}>ChangeEmailAddress</button>
      </div>
    );
  }
}
export default UserInfo;