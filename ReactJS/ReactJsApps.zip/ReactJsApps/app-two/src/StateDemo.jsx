//program to demonstrate state management inside a class component
import { Component } from "react";

class StateDemo extends Component {
  constructor(props) {
    super(props);
    this.state = { btnClickStatus: false };
  }

  handleClick = () => {
    this.setState({ btnClickStatus: !this.state.btnClickStatus });
  };

  render() {
    return (
      <div>
        <h1>StateManagement-Demo</h1>
        <button onClick={this.handleClick}>ClickMe</button>

        {this.state.btnClickStatus ? (
          <p>Welcome to StateManagement</p>
        ) : (
          <p>U have to Click</p>
        )}
      </div>
    );
  }
}

export default StateDemo;
