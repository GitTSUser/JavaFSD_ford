//program to demonstrate making use of Component state for managing user details
import { Component } from "react";

class UserDetails extends Component {
  constructor(props) {
    super(props);
    this.state = {
      users: [
        { id: 1, name: "Sumanth", age: 20 },
        { id: 2, name: "Raj", age: 32 },
      ],
    };
  }

  addMoreUsers = () => {
    const u_name = prompt("Enter new user name:");
    const u_age = parseInt(prompt("Enter user age:"));

    const new_user = {
      id: this.state.users.length + 1,
      name: u_name,
      age: u_age,
    };

    this.setState({
      users: [...this.state.users, new_user],
    });
  };

  render() {
    return (
      <div>
        <h1>User Details (Managed by Component State)</h1>

        <table style={{ marginLeft: "40px", backgroundColor: "lightcyan" }}>
          <thead>
            <tr>
              <th>UserId</th>
              <th>Name</th>
              <th>Age</th>
            </tr>
          </thead>
          <tbody>
            {this.state.users.map((user) => (
              <tr>
                <td>{user.id}</td>
                <td> {user.name}</td>
                <td> {user.age}</td>
              </tr>
            ))}
          </tbody>
        </table>

        <button onClick={this.addMoreUsers}>Add User</button>
      </div>
    );
  }
}

export default UserDetails;