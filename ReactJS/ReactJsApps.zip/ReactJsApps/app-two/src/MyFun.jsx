//functional component to receive props

function MyFun(props) {
  return (
    <div>
      <h2>Welcome to FunctionalComponent</h2>
      <p>
        Product details:{props.funProduct.id} {props.funProduct.name}{" "}
        {props.funProduct.price} {props.funProduct.qty}
      </p>
    </div>
  );
}

export default MyFun;