import "./App.css";
import MyApp from "./MyApp";
import MyFun from "./MyFun";
import StateDemo from "./StateDemo";
import UserDetails from "./UserDetails";
import UserInfo from "./UserInfo";

function App() {
  let myAppHeadline = "Welcome to MyApp";

  let product = { id: 1002, name: "super-fan", price: 3500.25, qty: 12 };

  return (
    <div>
      {/* <h1>Welcome to AppComponent</h1> */}

      {/* <MyApp heading={myAppHeadline} myProduct={product}></MyApp>
      <hr/>
      <MyFun funProduct={product}/>
       */}

       <UserDetails></UserDetails>
     
        {/*  <hr/> <UserInfo></UserInfo>
       <StateDemo></StateDemo> */}
    </div>
  );
}

export default App;
