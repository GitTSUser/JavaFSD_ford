import { Component } from "react";

class MyApp extends Component {

  render() {
    return (
      <div>
        <h2>{this.props.heading}</h2>
        <h3>Product Info</h3>
        <p>
          Id: {this.props.myProduct.id} Name: {this.props.myProduct.name}
        </p>
        <p>
          Price: {this.props.myProduct.price} Qunaity:{" "}
          {this.props.myProduct.qty}
        </p>

        <p style={{ color: "red" }}>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Nemo est ab
          quaerat, laborum quos consectetur repellat iure distinctio maiores
          debitis recusandae dolore asperiores, architecto perferendis sequi!
          Aspernatur laboriosam dolorem dignissimos.
        </p>
      </div>
    );
  }
}

export default MyApp;
