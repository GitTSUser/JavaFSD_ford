import "./App.css";

import "bootstrap/dist/css/bootstrap.min.css";
import { useEffect, useState } from "react";
import axios from "axios";
import ProductsInfo from "./ProductsInfo";
import ProductForm from "./ProductForm";

function App() {
  const backendServiceUrl = "http://localhost:3000";

  const [products, setProducts] = useState([]);

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const response = await axios.get(backendServiceUrl + "/products");

      setProducts(response.data);
    } catch (error) {
      console.error("Error :", error.message());
    }
  };


  let handleAddProduct=(newProduct)=>{
    setProducts([...products,newProduct]);
  }
  return (
    <div className="container bg-info">
      <h1 className="text-white text-center text-decoration-underline">Welcome to React With Axios</h1>

<ProductForm onAddProduct={handleAddProduct}/>
      <ProductsInfo items={products} />
    </div>
  );
}

export default App;
