import React from 'react';

function ProductsInfo({items}) {
    return (
        <div className='bg-info text-white'>
            <h2>Product Info:</h2>

            <ul>
                {
                    items.map(product=>{
                        return <li key={product.id}>
                            <strong>{product.name}</strong> - ${product.price}  - Qty : {product.qty}</li>
                    })
                }
            </ul>
        </div>
    );
}

export default ProductsInfo;