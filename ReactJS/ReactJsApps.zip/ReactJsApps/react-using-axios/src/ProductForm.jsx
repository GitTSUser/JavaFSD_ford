import axios from "axios";
import React, { useState } from "react";

function ProductForm({ onAddProduct }) {
  const backendServiceUrl = "http://localhost:3000";
  const [product, setProduct] = useState({
    id: "",
    name: "",
    price: "",
    qty: "",
  });

  let handleSubmit = async (e) => {
    e.preventDefault(); //prevents default form submission

    try {
      const response = await axios.post(
        backendServiceUrl + "/products",
        product
      );

      onAddProduct(response.data);

      setProduct({ id: "", name: "", price: "", qty: "" });
    } catch (error) {
      console.error("Error is:" + error.message());
    }
  };

  let handleChange=(e)=>{
    const {name,value}=e.target;

    setProduct({...product,[name]:value})

  }

  return (
    <div>
      <h3 className="text-white">Add Product</h3>
      <form onSubmit={handleSubmit}>
        <input type="text" name="id" value={product.id} placeholder="ID"  onChange={handleChange}/>
        <br/>
        <input
          type="text"
          name="name"
          value={product.name}
          placeholder="NAME" onChange={handleChange}
        /><br/>

        <input
          type="text"
          name="price"
          value={product.price}
          placeholder="PRICE" onChange={handleChange}
        /><br/>

        <input
          type="number"
          name="qty"
          value={product.qty}
          placeholder="QUANTITY" onChange={handleChange}
        /><br/>

        <button type="submit">AddProduct</button>
      </form>
    </div>
  );
}

export default ProductForm;
