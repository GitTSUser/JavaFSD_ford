//program to demonstrate making use of  useState hook
import { useState } from "react";

import "./App.css";

function App() {
  const [count, setCount] = useState(0);

  const handleClick = () => {
    setCount(count + 1);
    console.log("click is counted");
  };

  const handleReset = () => {
    alert("counter being reset");
    setCount(0);
  };

  return (
    <div>
      <button onClick={handleClick}>ClickMe</button>

      <button onClick={handleReset}>Reset</button>

      <p> You clicked button for {count} times</p>
    </div>
  );
}

export default App;