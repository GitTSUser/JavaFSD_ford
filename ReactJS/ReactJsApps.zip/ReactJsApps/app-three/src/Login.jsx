import { useRef } from "react";

function Login(props) {
    //useRef hook is useful to hold some data of an input field
  let unRef = useRef("Username");
  let upRef = useRef("Password");

  return (
    <div className="container bg-info">
      <h2 className="text-center text-white">Login Here!</h2>

      <form
        onSubmit={(event) => {
          event.preventDefault();
          props.handleLogin(unRef.current.value, upRef.current.value);
        }}
      >
        <label>Username:</label>
        <input type="text" name="un" ref={unRef} placeholder="Username" />
        <br />
        <label>Password:</label>
        <input type="password" name="up" ref={upRef} placeholder="Password" />
        <br />
        <br />
        <input type="submit" name="s" value="Login" />
        &nbsp;&nbsp;
        <input type="reset" name="c" value="Clear" />
      </form>
    </div>
  );
}

export default Login;