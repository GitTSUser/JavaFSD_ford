//program to demonstrate working with useEffect hook

import { useEffect, useState } from "react";

//useEffect hook will be helpful to perform some special operations

//like data fetching from a service, updating the DOM etc.

 let EffectHook=()=>{

    const[counter,setCounter]=useState(0);


    useEffect(()=>{
        setTimeout(()=>setCounter(counter+1),1000)
    },[])



    return (
        <div className="container bg-info">
            <h1 className="bg-warning text-center">Welcome to useEffect demo</h1>
        <p>I am counting and current value is {counter}</p>
        </div>
    )


}

export default EffectHook;