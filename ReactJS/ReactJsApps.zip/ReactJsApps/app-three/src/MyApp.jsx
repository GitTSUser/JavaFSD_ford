import { useState } from "react";
import Welcome from "./Welcome";
import Login from "./Login";

function MyApp() {
  const [loginStatus, setLoginStatus] = useState(false);

  const[userInfo,setUserInfo]=useState({uname:"",upwd:""});

  let userLogin=(name,pwd)=>{

    if(name=='arun' && pwd=='arun@123'){
    alert("Mr/Mrs "+name+", you are logged into website");
    setLoginStatus(true);
    setUserInfo({uname:name,upwd:pwd})
    }else{
    alert("Your details are not valid so, you are redirected to Login page");
    }
  }


  return <div>{loginStatus ? <Welcome userData={userInfo}/> : <Login handleLogin={userLogin}/>}</div>;
}

export default MyApp;
