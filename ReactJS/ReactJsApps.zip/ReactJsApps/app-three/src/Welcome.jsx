
const Welcome=(props)=>{

    return (
        <h2 className="text-success">Welcome to {props.userData.uname} to Website..!</h2>
    )
}

export default Welcome;