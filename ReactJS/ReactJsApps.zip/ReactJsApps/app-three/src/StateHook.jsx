//program demonstrate tracking the data or state of a component using useState hook

import { useState } from "react";

const StateHook = () => {

    const[color,setColor]=useState('white');

    return (
        <div className="container bg-info mt-3">
        <h2 className="text-center">Welcome to useState hook demo</h2>

        <button style={{backgroundColor:color}} onClick={()=> setColor('blue')}>
            Blue
        </button>
        <button style={{backgroundColor:color}} onClick={()=> setColor('red')}>
            Red
        </button>
        <button style={{backgroundColor:color}} onClick={()=> setColor('green')}>
            Green
        </button>
        <button style={{backgroundColor:color}} onClick={()=> setColor('white')}>
            White
        </button>
        </div>
    )


};


export default StateHook;