//program to print the time for every 1000ms by using useEffect hook

import { useEffect, useState } from "react";

function EffectTimeHook() {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timerId = setInterval(() => setTime(new Date()), 1000);

    //clean up function
    return () => {
      clearInterval(timerId);
    };
  }, []);

  return (
    <div className="container">
      <h2 className="text-center">Clock demo using useEffect</h2>

      <p className="text-success">Time is: {time.toLocaleTimeString()}</p>
    </div>
  );
}

export default EffectTimeHook;
