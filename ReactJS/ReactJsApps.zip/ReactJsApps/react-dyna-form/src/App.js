import { useState } from "react";
import "./App.css";
import Form from "./components/Form";
import DisplayFormData from "./components/DisplayFormData";

function App() {
  const [submittedData, setSubmittedData] = useState(null);

  let handleSubmit = (formData) => {
    setSubmittedData(formData);
  };

  return (
    <div className="container bg-warning">
      <h1 style={{backgroundColor:'lightblue',textAlign:'center'}}>Welcome to Dynamic Form in React</h1>

      <h3 className="text-center text-primary">Register Form</h3>
      <Form onSubmit={handleSubmit} />

      {submittedData && <DisplayFormData formData={submittedData} />}
    </div>
  );
}

export default App;