import React from "react";
import { useState } from "react";
import {
  CheckBoxCtrl,
  DateCtrl,
  EmailCtrl,
  PasswordCtrl,
  RadioBtn,
  SelectBoxCtrl,
  TextCtrl,
} from "./FormControls";

const Form = ({onSubmit}) => {
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    pwd: "",
    email: "",
    gender: "",
    dob: "",
    married: false,
    country: "",
  });

  let handleClear=(e)=>{

    setFormData({
        firstName: "",
        lastName: "",
        pwd: "",
        email: "",
        gender: "",
        dob: "",
        married: false,
        country: ""
            
    })
  }

  let handleChange = (e) => {
    const { name, value, type, checked } = e.target;

    setFormData((prevFormData) => ({
      ...prevFormData,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const handleSubmit=(e)=>{

        e.preventDefault();

        onSubmit(formData);

  }


  return (
    <div>
      <form onSubmit={handleSubmit}>
        <TextCtrl          label={"Firstname"} name="firstName"
          value={formData.firstName}
          onChange={handleChange}
        />

        <TextCtrl
          label={"Lastname"}
          name="lastName"
          value={formData.lastName}
          onChange={handleChange}
        />

        <PasswordCtrl
          label={"password"}
          name="pwd"
          value={formData.pwd}
          onChange={handleChange}
        />

        <EmailCtrl
          label={"EmailId"}
          name="email"
          value={formData.email}
          onChange={handleChange}
        />

        <RadioBtn
          label={"Male"}
          name="gender"
          value={"male"}
          onChange={handleChange}
        />
        <RadioBtn
          label={"Female"}
          name="gender"
          value={"female"}
          onChange={handleChange}
        />

        <DateCtrl
          label={"DoB"}
          name="dob"
          value={formData.dob}
          onChange={handleChange}
        />

        <CheckBoxCtrl
          label={"Are U married ?"}
          name="married"
          checked={formData.married}
          onChange={handleChange}
        />

        <SelectBoxCtrl
          label={"Country"}
          name="country"
          options={["INDIA", "USA", "UAE", "UK", "USSR", "AUS"]}
          value={formData.country}
          onChange={handleChange}
        />

        <button type="submit">Submit</button>
        <button type="reset" onClick={handleClear}>Clear</button>
      </form>
    </div>
  );
};

export default Form;
