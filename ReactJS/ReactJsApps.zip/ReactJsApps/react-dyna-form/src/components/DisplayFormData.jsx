import React from "react";

function DisplayFormData({ formData }) {
  return (
    <div className="container bg-primary text-white">
      <h1>Your Data is:</h1>

      <p>First Name: {formData.firstName}</p>
      <p>Last Name: {formData.lastName}</p>
      <p>Password:{formData.pwd}</p>
      <p>Email Id: {formData.email}</p>
      <p>Gender: {formData.gender}</p>
      <p>DateOfBirth:{formData.dob}</p>
      <p>Is Married:{formData.married ? "yes" : "no"}</p>
      <p>Country:{formData.country}</p>
    </div>
  );
}

export default DisplayFormData;
