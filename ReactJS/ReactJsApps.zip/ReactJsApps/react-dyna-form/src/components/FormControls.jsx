

const TextCtrl=({label,name,value,onChange})=>{

    return (
        <div>
            <label>{label}</label>
            <input type="text" name={name}  value={value} onChange={onChange}/>
        </div>
    )
}

const PasswordCtrl=({label,name,value,onChange})=>{

    return (
        <div>
            <label>{label}</label>
            <input type="password" name={name}  value={value} onChange={onChange}/>
        </div>
    )
}


const EmailCtrl=({label,name,value,onChange})=>{

    return (
        <div>
            <label>{label}</label>
            <input type="email" name={name}  value={value} onChange={onChange}/>
        </div>
    )
}


const RadioBtn=({label,name,value,onChange})=>{

    return (
        <div>
            <label>{label}</label>
            <input type="radio" name={name}  value={value} onChange={onChange}/>
        </div>
    )
}

const DateCtrl=({label,name,value,onChange})=>{

    return (
        <div>
            <label>{label}</label>
            <input type="date" name={name}  value={value} onChange={onChange}/>
        </div>
    )
}



const CheckBoxCtrl=({label,name,checked,onChange})=>{

    return (
        <div>
            <label>{label}</label>
            <input type="checkbox" name={name}  checked={checked} onChange={onChange}/>
        </div>
    )
}


const SelectBoxCtrl=({label,name,options,value,onChange})=>{

    return (
        <div>
            <label>{label}</label>
            <select name={name} value={value} onChange={onChange}>
            {
                options.map((option)=><option key={option} value={option}>{option}</option>)
            }

            </select>
        </div>
    )
}


export {TextCtrl,PasswordCtrl,EmailCtrl,RadioBtn,DateCtrl,CheckBoxCtrl,SelectBoxCtrl}
