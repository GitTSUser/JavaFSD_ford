import "./App.css";
import Popup from "./Popup";
import { useState } from "react";

function App() {

  const[popupStatus,setPopupStatus]=useState(false);

  let handleClick=()=>{
    setPopupStatus(true);
  };

  let closePopup=()=>{
    setPopupStatus(false);
  }

  return (
    <div className="container bg-warning">
      <h1 className="text-center bg-info text-white">Welcome to React Portal Demo</h1>

      <p>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam dictum
        augue ut urna rhoncus, id posuere quam auctor. Donec placerat ut risus
        eget aliquet. In vel fermentum ipsum, in vestibulum purus. Vestibulum
        varius in massa id tincidunt. Morbi accumsan imperdiet rutrum.
        Vestibulum venenatis nunc eu augue sollicitudin, a ornare est iaculis.
        Donec congue, nulla sed facilisis ultrices, lectus tortor efficitur
        dolor, sed lobortis tellus sapien in felis. Mauris euismod lectus arcu,
        in faucibus arcu luctus in. Aenean iaculis ligula diam, id iaculis enim
        venenatis nec. Aenean ut maximus mi. Praesent consectetur ornare eros
        facilisis porta. Sed ipsum odio, scelerisque ac condimentum nec, commodo
        ut nulla. Morbi tristique leo in blandit scelerisque. Praesent in metus
        molestie, egestas nunc imperdiet, porta sapien. Nullam volutpat
        ultricies gravida.
      </p>
      <p>
        <button onClick={handleClick}>ClickMe</button>
      </p>

    {popupStatus? <Popup handleClose={closePopup} /> : ''}

      <footer className="bg-info">
        <p className="text-center">developed by You at Ford</p>
      </footer>
    </div>
  );
}
export default App;