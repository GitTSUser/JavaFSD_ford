import React from "react";
import ReactDOM from "react-dom";

function Popup(props) {
  return ReactDOM.createPortal(
    <div
      className="bg-dark text-white text-center"
      style={{
        width: "350px",
        height: "150px",
        position: "absolute",
        top: "20%",
        left: "35%",
      }}
    >
      <h2>Hi, I am Popup</h2>
      <p>I am here waiting to see you!</p>
      <button onClick={props.handleClose}>Close</button>
    </div>,
    document.body
  );
}
export default Popup;
