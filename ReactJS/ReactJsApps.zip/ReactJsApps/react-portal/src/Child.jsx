import React from "react";

function Child(props) {
  return (
    <React.Fragment>
      <h2>I am Child App</h2>

      <p>I am taking tasks here</p>
    </React.Fragment>
  );
}

export default Child;