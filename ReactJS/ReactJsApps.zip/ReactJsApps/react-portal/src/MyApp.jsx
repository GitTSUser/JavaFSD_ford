import React from 'react';
import Child from './Child';

function MyApp(props) {
    return (

        <div className='text-center'>
        <h1>Welcome to MyApp</h1>

            <Child/>
        </div>

    );
}

export default MyApp;