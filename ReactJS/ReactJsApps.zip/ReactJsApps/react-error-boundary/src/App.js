import logo from "./logo.svg";
import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import UserList from "./UserList";
import ErrorBoundary from "./ErrorBoundary";

function App() {
  return (
    <div className="container bg-primary text-white">
      <h1 className="text-center">Welcome to ErrorBoundary Demo</h1>

      <ErrorBoundary>
        <UserList  />
      </ErrorBoundary>
    </div>
  );
}

export default App;
