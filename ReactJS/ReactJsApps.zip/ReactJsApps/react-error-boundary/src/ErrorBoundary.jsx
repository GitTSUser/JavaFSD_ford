import React, { Component } from 'react';

class ErrorBoundary extends Component {
    constructor(props) {
        super(props);
        this.state={hasError:false};
    }

    static getDerivedStateFromError(error){
        console.log("getDerivedStateFromError called")
        return {hasError:true};
    }

    componentDidCatch(error, errorInfo){
        console.log("componentDidCatch called")
        console.error('Error caught by ErrorBounary',error,errorInfo)
    }

    render() {

        if(this.state.hasError){
            return <div>Service is not available at the moment! Pls try after sometime.</div>
        }

        return this.props.children;
    }
}


export default ErrorBoundary;