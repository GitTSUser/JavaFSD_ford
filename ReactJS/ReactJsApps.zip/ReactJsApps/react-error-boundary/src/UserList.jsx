import React, { useEffect, useState } from "react";

function UserList(props) {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    fetchUserInfo();
  }, []);

  let fetchUserInfo = () => {
    fetch("http://localhost:3000/customer")
      .then((resp) => resp.json())
      .then((data) => setUsers(data))
      .catch((error) => {
        console.error("Error fetching users:", error);
      });
  };

  return (
    <div>
      <h2>User Details:</h2>

      <ul>
        {users.length!=0?users.map((user,idx) => {
          return (
            <li key={user.id}>
              <strong> {user.name} </strong> - {user.email} - {user.phone}
            </li>
          );
        })
        :""
    }
      </ul>
    </div>
  );
}

export default UserList;
