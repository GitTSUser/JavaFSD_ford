//program to demonstrate the lifecycle methods for mounting phase.

import './App.css';
import { Component } from 'react';

class App extends Component {
  

  constructor(props){
    super(props);
    console.log("constructor is called");
    this.state={
      count:0
    }
  }

  componentDidMount(){
    console.log("ComponentDidMount is called");

    setTimeout(() => {
      this.setState({count:100})
    }, (2000));
  }

  static getDerivedStateFromProps(props,state){

    console.log("getDerivedStateFromProps is called");

    if(props.initalCount!==state.count){
      return {
        count:25
      }
    }
    return  null;
  }

  render() {

    console.log("render called")
    return (
      <div>
        <h1>Welcome to App</h1>
        <p>Count is:{this.state.count}</p>
      </div>
    );
  }


}

export default App;
