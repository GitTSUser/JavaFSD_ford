//program to demonstrate component updation phase
import { Component } from "react";

class MyApp extends Component{


    constructor(props){
        super(props);
        console.log("constructor called");
        this.state={
            counter:0
        }
    }

    shouldComponentUpdate(){
        console.log("shouldComponentUpdate is called")
        if(this.state.counter!=0){
         
        if(this.state.counter==5){
            return true;
        }
            console.log("shouldComponentUpdate is returning false")
        return false;
        }
        console.log("shouldComponentUpdate is returning true")
        return true;
    }


    handleClick=()=>{

        console.log("handleClick called h")
        this.setState(prevState=>({
            counter:prevState.counter+1
        }))
    }

    componentDidUpdate(){
        console.log("componentDidUpdate is called");
    }

    componentWillUnmount(){
    console.log("component being unmounted from DOM");
    alert("Component is being unmounted from DOMM")
    
    }

    render() {
        console.log("Render is called")
        return (
            <div>
                <p>Counter value is:{this.state.counter}</p>

                <button onClick={this.handleClick}>IncreaseCounter</button>
            </div>
        );
    }




}

export default MyApp;