function Main(props) {
  return (
    <div>
      <h1>Your content goes here..!</h1>
      <ul style={{color:'white'}}>
        {props.mainData &&
          props.mainData.map((item, idx) => {
            return <li key={idx}>{item}</li>;
          })}
      </ul>
    </div>
  );
}

export default Main;
