

function SideBar({onContentChange}){

    let fruits=['banana','mango','orange','grapes'];

    let flowers=['rose','lilly','jasmine'];

    let colors=['red','green','blue','yellow'];

    const displayContent=(name)=>{

        if(name==='fruits'){
            onContentChange(fruits);
        }else if(name==='flowers'){
            onContentChange(flowers)
        }else if(name==='colors'){
            onContentChange(colors);
        }
    }


    return  (
        <ul className="bg-warning" style={{listStyle:'none'}}>
            <li>
                <a onMouseOver={()=> displayContent('fruits')}>Fruits</a>
            </li>
            <li>
                <a onMouseOver={()=> displayContent('flowers')}>Flowers</a>
            </li>
            <li>
                <a onMouseOver={()=> displayContent('colors')}>Colors</a>
            </li>
        </ul>
    )

}

export default SideBar;