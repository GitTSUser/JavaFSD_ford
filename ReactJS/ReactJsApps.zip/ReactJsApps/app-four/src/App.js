import "./App.css";
import Header from "./Header";
import SideBar from "./SideBar";
import Main from './Main';
import Footer from "./Footer";
import { useState } from "react";

function App() {

  const [content,setContent]=useState([]);

  const handleContent= (newContent)=>{
    console.log('handleContent called')
    setContent(newContent);
    console.log("new content is:"+newContent)
  }
  
  return (
    <div className="container bg-info mt-4">
      <div className="row">
        <Header />
      </div>
      <div className="row bg-warning" style={{height:'260px'}}>
        <div className="col-4">
          <SideBar  onContentChange={handleContent} />
        </div>
        <div className="col-8 bg-primary">       
          <Main mainData={content} />
        </div>     
      </div>

      <div className="row bg-success">
      <Footer/>
      </div>
    </div>
  );
}

export default App;
