

function Header(){

    return <h1 className="text-center text-white">Welcome to React WebSite</h1>
}

export default Header;