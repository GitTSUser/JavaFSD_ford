
function Footer(){

    return (
        <p className="text-white text-center">Developed by You at Ford&trade;</p>
    )
}

export default Footer;