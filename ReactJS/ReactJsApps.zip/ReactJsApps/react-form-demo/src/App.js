import { useState } from 'react';
import './App.css';
import Form from './components/Form';
import DisplayFormData from './DisplayFormData';

function App() {

  const[submittedData,setSubmittedData]=useState(null);

  let handleSubmit=(formData)=>{

    setSubmittedData(formData);
  }


  return (
    <div className="container bg-info">
     
     <h1 className='text-center'>Welcome to React Form Demo</h1>
     
     <Form onSubmit={handleSubmit}></Form>

    {
      submittedData && <DisplayFormData  formData={submittedData}/>
    }

    </div>
  );
}

export default App;
