import React from "react";

function DisplayFormData({ formData }) {
  return (
    <div className="container bg-warning">
      <h2>Your Data is:</h2>

      <p>Name: {formData.name}</p>
      <p>Email: {formData.email}</p>
      <p>Gender: {formData.gender}</p>
      <p>DoB: {formData.birthDate}</p>
      <p>TermsAgreed: {formData.termsAgreed}</p>
      <p>Country:{formData.country}</p>
    </div>
  );
}

export default DisplayFormData;