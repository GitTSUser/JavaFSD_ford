import React, { useState } from 'react';
import { CheckBox, DateControl, EmailControl, RadioBtn, SelectBox, TextControl } from './FormControls';

const Form=({onSubmit})=> {

   const[formData,setFormData]= useState({
        name:'arun',
        email:'arun@yahoo.com',
        gender:'male',
        birthDate:'12/08/2002',
        termsAgreed:false,
        country:'INDIA'
    })

    const handleChange=(e)=>{

        console.log(e.target.value);
        const {name,value,type,checked}=e.target;

        setFormData(prevData=>({
            ...prevData,
            [name]:type==='checkbox'?checked : value
        }));
    };


    const handleSubmit=(e)=>{
        e.preventDefault();
        onSubmit(formData)
    }


    return (
        <div>
            <form onSubmit={handleSubmit}>
            
            <TextControl label={"Name"} name="name" value={formData.name} onChange={handleChange}/>
            <EmailControl label={"Email"} name="email" value={formData.email} onChange={handleChange}/>

            <RadioBtn label={"Male"} name="gender" value="male" onChange={handleChange}/>
            <RadioBtn label={"Female"} name="gender" value="female" onChange={handleChange}/>

            <DateControl label={"Date Of Birth"} name='birthDate' value={formData.birthDate} onChange={handleChange}/>

            <CheckBox label={"I agree to condtions"} name="termsAgreed" checked={formData.termsAgreed} onChange={handleChange}/>

            <SelectBox label={"Country"} name="country" options={['INDIA','USA','UK','USSR','UAE']} value={formData.country} onChange={handleChange}/>

            <button type='submit'>Submit</button>
            </form>

        </div>
    );
}

export default Form;
