//program to have form controls

const TextControl = ({ label, value, onChange }) => {
  return (
    <div>
      <label>{label}</label>
      <input type="text" value={value} onChange={onChange}/>
    </div>
  );
};

const EmailControl = ({ label, value, onChange }) => {
  return (
    <div>
      <label>{label}</label>
      <input type="email" value={value} onChange={onChange} />
    </div>
  );
};

const RadioBtn = ({ label, value, onChange }) => {
  return (
    <div>
      <label>{label}</label>
      <input type="radio" value={value} onChange={onChange} />
    </div>
  );
};

const DateControl = ({ label, value, onChange }) => {
  return (
    <div>
      <label>{label}</label>
      <input type="date" value={value} onChange={onChange} />
    </div>
  );
};

const CheckBox = ({ label, checked, onChange }) => {
  return (
    <div>
      <label>{label}</label>
      <input type="checkbox" checked={checked} onChange={onChange} />
    </div>
  );
};

const SelectBox = ({ label, options, value, onChange }) => {
  return (
    <div>
      <label>{label}</label>

        <select value={value} onChange={onChange}>
            {
                options.map(option=><option key={option} value={option}>{option}</option>)
            }

        </select>

    </div>
  );
};


export {TextControl,EmailControl,RadioBtn,DateControl,CheckBox,SelectBox}