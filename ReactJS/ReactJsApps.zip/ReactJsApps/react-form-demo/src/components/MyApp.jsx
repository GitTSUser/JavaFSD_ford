import React from "react";
import { useState } from "react";

function MyApp(props) {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    gender: "",
    country: "",
  });

  let handleChange = (e) => {
    const { name, value } = e.target;

    setFormData({
      ...formData,
      [name]: value,
    });
  };
  let handleSubmit = (e) => {
    e.preventDefault();
    console.log(e.target.value);
    console.log(formData);
  };

  return (
    <div>
      <h1>React Form</h1>

      <div>
        {JSON.stringify(formData)}
      </div>
      <form onSubmit={handleSubmit}>
        <label>Username:</label>
        <input
          type="text"
          name="name"
          value={formData.name}
          onChange={handleChange}
          placeholder="Username"
        />
        <br />
        <br />
        <label>Email:</label>
        <input
          type="email"
          name="email"
          value={formData.email}
          placeholder="Username"
          onChange={handleChange}
        />
        <br />
        <br />
        <label>Phone:</label>
        <input
          type="phone"
          name="phone"
          value={formData.phone}
          placeholder="Phone"
          onChange={handleChange}
        />
        <br />
        <br />
        <input
          type="radio"
          name="gender"
          value="male"
          onChange={handleChange}
        />
        Male &nbsp;&nbsp;
        <input
          type="radio"
          name="gender"
          value="female"
          onChange={handleChange}
        />
        Female
        <br />
        <br />
        <select name="country" value={formData.country} onChange={handleChange}>
          <option>--Country--</option>
          <option>USA</option>
          <option>UK</option>
          <option>CANADA</option>
        </select>
        <br />
        <br />
        <input type="submit" name="s" value="Save" />
      </form>
    </div>
  );
}

export default MyApp;
