import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import UserInfo from './UserInfo';

function App() {



  return (
    <div className="App">

    <UserInfo/>


    </div>
  );
}

export default App;
