import React from 'react';
import { useState } from 'react';

function UserInfo(props) {

     const [usernames,setUsernames]=useState([
            'arun','arvind','aman','ashutosh',
            'anurag','jane','john','jasmine','mittu','sundhar',
            'sumanth','surag','tamilan','kabilan','maithili','mohan',
            'harsha','sanmugan'
     ]);

     const[filteredUsernames,setFilteredUsernames]=useState([]);

     const handleTextChange=(e)=>{

        const inputText=e.target.value.toLowerCase();

        console.log("you entered is:"+inputText);     
        
        const matchedNames=usernames.filter((uname)=> uname.includes(inputText));
        setFilteredUsernames(matchedNames);
     }

    return (
        <>
            <h1>Welcome to User Directory App</h1>

            <input type='text' onChange={handleTextChange} placeholder='Search Username'/>


            <h2 className='text-start'>Available Names:</h2>
            <ul>

            {
                filteredUsernames.map((uname,idx)=>{
                    return <li style={{listStyle:'none'}} key={idx}>{idx+1} {uname}</li>
                })
            }

            </ul>      
        </>
    );
}

export default UserInfo;