import logo from './logo.svg';
import './App.css';
import {Routes,Route} from 'react-router-dom';
import Home from './components/Home';
import Careers from './components/Careers';
import NavBar from './components/NavBar';
import Contact from './components/Contact';
import PageNotFound from './components/PageNotFound';
import CareerDetails from './components/CareerDetails';
import ITJobs from './components/ITJobs';
import NonITJobs from './components/NonITJobs';

function App() {
  return (
    <div className='container'>
    <h1 className='text-center bg-info'>Welcome to Routing Demo</h1>
   
   <NavBar/>
    <Routes>
        <Route path='home' Component={Home}/>
        <Route path='careers' Component={Careers}>
            <Route path='it-jobs' Component={ITJobs}/>
            <Route path='nonit-jobs' Component={NonITJobs}/>
          </Route>
        <Route path="contact" Component={Contact}/>
        <Route path='career-details' Component={CareerDetails}/>
        <Route path='*' Component={PageNotFound}/>
    </Routes>
    </div>

  );
}

export default App;
