import React from 'react';

function PageNotFound(props) {
    return (
        <div>
            <br/><br/>
            <h2 className='text-danger'>Page Not Found !</h2>
        </div>
    );
}

export default PageNotFound;