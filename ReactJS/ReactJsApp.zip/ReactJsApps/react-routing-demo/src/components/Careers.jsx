import React from "react";
import { Link,Outlet } from "react-router-dom";

function Careers(props) {
  return (
    <>
    <br/>
      <p>
      <strong>Careers for you!</strong> Lorem, ipsum dolor sit amet consectetur adipisicing
        elit. Ratione, laborum in eos cumque nesciunt non optio repellendus
        suscipit autem quas repellat tempora eaque dicta perspiciatis alias
        saepe iusto itaque quisquam.
      </p>
      <nav>
        <Link to="it-jobs">IT-Jobs</Link> &nbsp;&nbsp;&nbsp;
        <Link to="nonit-jobs">Non-IT-Jobs</Link>
      </nav>
      <Outlet/>
    </>
  );
}

export default Careers;
