import React from 'react';
import { Link, NavLink } from 'react-router-dom';

function NavBar(props) {
    return (
        <nav>

            <NavLink to="/home">Home</NavLink> &nbsp;&nbsp;
            <NavLink to="/careers">Careers</NavLink>&nbsp;&nbsp;
            <NavLink to="/contact">Contact</NavLink>
            
        </nav>
    );

}
export default NavBar;