import React from 'react';
import { useNavigate } from 'react-router-dom';


function CareerDetails(props) {


    const navigate=useNavigate();
    
    let careers=["Java Developer","ReactJs Developer","Cloud Architect","Selenium Tester","UI/UX Developer","DevOps Engineer"]

    return (
        <div>
            <br/>
            <br/>
            <h3>CareerDetails:</h3>
            <ul>
            {
                careers.map((job,idx)=>{

                    return <li  style={{listStyle:'none'}} key={idx}>{idx+1} . {job}</li>

                })
            }
            </ul>

            <button onClick={()=> navigate(-1)}>Go back</button>
        </div>
    );
}

export default CareerDetails;