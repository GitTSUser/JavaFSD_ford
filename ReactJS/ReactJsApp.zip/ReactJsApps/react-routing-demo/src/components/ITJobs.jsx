import React from 'react';

function ITJobs(props) {

    jobs=["Java Developer","Cloud Architect","Tester","DevOps Engineer","Data Scientist"];
    return (
        <div>

            <h2 className='text-success'>IT Jobs</h2>

            <ul>
            {
                jobs.map((job,idx)=><li key={idx}>{job}</li>)
            }
            </ul>
        </div>
    );
}

export default ITJobs;