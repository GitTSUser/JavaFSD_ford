import React from 'react';

function Contact(props) {
    return (
        <div>
            <br/>
            <br/>
            <pre>
                <strong className="text-info">Contact</strong><br/>
                Suite No: #420,<br/>
                RR nagar,<br/>
                Medavakkam,<br/>
                Chennai, TN
            </pre>
        </div>
    );
}

export default Contact;