import React from 'react';

function NonITJobs(props) {
    return (
        <div>

            <h3 className='text-warning'>NonIT Jobs</h3>
         <ul>
            {
                ["IAS","IPS","CA","Clerk","PO"].map((job,idx)=><li key={idx}>{job}</li>)
            }    
        </ul>   
        </div>
    );
}

export default NonITJobs;