import React from 'react';

import {useNavigate} from 'react-router-dom';

function Home(props) {
   
    const navigate=useNavigate();

    return (
        <div>
            <p>Welcome to Home Page</p>
            <br/>
            <br/>
            <button onClick={()=> navigate('/career-details') }>Career Options</button>
        </div>
    );
}

export default Home;