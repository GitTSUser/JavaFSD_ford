import logo from "./logo.svg";
import "./App.css";
import { useState } from 'react';

function App() {

  const[text,setText]=useState('');

  let handleChange=(e)=>{
    setText(e.target.value);
  }

  return (
    <>
      <h1>Welcome to App</h1>

      <div>
        <label htmlFor="text">Input:</label>
        <input type='text' id="text" name={text} value={text} placeholder="Enter Anything" onChange={handleChange}/>

        <br/><br/>

        <p>
          You entered is: {text}
        </p>
      </div>
    </>
  );
}

export default App;
