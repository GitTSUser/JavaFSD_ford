import { render, screen } from "@testing-library/react";
import App from "./App";

describe("App testing is OK", () => {

  beforeEach(()=>{
    render(<App/>);
  })

  test("should App component render heading", () => {
    //render(<App />); //rendering App component
    screen.getByText("Welcome to App"); //accessing text
    screen.debug(); //printing the screen dom on the test console

    expect(screen.getByText("Welcome to App")).toBeInTheDocument(); //assertion of the testcase
  });

  test("should App Component doesnt render heading and throws error", () => {
    //render(<App />);
    let error;
    try {
      screen.getByText("Hello to App");
    } catch (err) {
      error = err;
    }

    expect(error).toBeDefined();
  });

  test("should App component have a lable", () => {
    //render(<App />); //rendering the component
    screen.getByLabelText("Input:"); //accessing label
    screen.debug(); //print the ui of component on console

    expect(screen.getByLabelText("Input:")).toBeInTheDocument(); // assertion
  });
});
