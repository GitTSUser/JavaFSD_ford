package com.ford.apps;

public class MathApp {	private CalculatorService calculatorService;

    public CalculatorService getCalculatorService() {
        return calculatorService;
    }

    public void setCalculatorService(CalculatorService calculatorService) {
        this.calculatorService = calculatorService;
    }

    public int addition(int num1, int num2) {

        System.out.println("MathApplication.addition() called");
        return calculatorService.add(num1, num2);
    }

    public int subtraction(int num1, int num2) {
        System.out.println("MathApplication.subtraction() called");
        return calculatorService.sub(num1, num2);
    }

    public int multiplication(int num1, int num2) {
        return calculatorService.mul(num1, num2);
    }
}

