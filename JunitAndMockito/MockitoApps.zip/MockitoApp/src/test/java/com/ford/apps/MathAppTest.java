package com.ford.apps;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import static org.junit.Assert.*;

public class MathAppTest {

    private MathApp mathApp;

    @Before
    public void setUp() throws Exception {
        mathApp = new MathApp();
    }

    @After
    public void tearDown() throws Exception {
        mathApp = null;
    }

    @Test
    public void addition() {
    }

    @Test
    public void subtraction() {

        CalculatorService cs = Mockito.mock(CalculatorService.class); // getting mock of CalculatorService
        mathApp.setCalculatorService(cs); // setting up mock to mathApp

        Mockito.when(cs.sub(20, 10)).thenReturn(100); // add subtraction behavior to the mock object (cs)

        int result = mathApp.subtraction(20, 10);

        System.out.println("sub result is:" + result);

        Mockito.verify(cs).sub(20, 10); // verify call happening on method or not

        assertEquals(100, result);
    }
}