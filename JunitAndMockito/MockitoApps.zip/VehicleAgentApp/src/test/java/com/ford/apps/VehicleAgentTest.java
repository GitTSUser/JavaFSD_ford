package com.ford.apps;

import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.*;

@RunWith(MockitoJUnitRunner.class)
public class VehicleAgentTest {

    @InjectMocks
    private VehicleAgent vehicleAgent;
    @Mock
    private Store storeMock;

    @org.junit.Before
    public void setUp() throws Exception {
    }

    @org.junit.After
    public void tearDown() throws Exception {
    }

    @org.junit.Test
    public void addNewVehicle() {

        Mockito.when(storeMock.addVehicle("Honda-Activa")).thenReturn(true);
       boolean actualResult= vehicleAgent.addNewVehicle("Honda-Activa");
        assertEquals(true,actualResult);
    }

    @org.junit.Test
    public void findVehicle() {
        Mockito.when(storeMock.getVehicle(100)).thenReturn("Honda");
        String actualResult= vehicleAgent.findVehicle(100);
        assertEquals("Honda",actualResult);
    }
}