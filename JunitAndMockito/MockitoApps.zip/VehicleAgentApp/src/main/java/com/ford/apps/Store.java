package com.ford.apps;

public interface Store {

    public boolean  addVehicle(String name);
    public String  getVehicle(int number);
    public boolean deleteVehicle(String name);
}
