package com.ford.apps;

public class VehicleAgent {
    private Store store;

    public void setStore(Store store){
        this.store=store;
    }

    public boolean addNewVehicle(String vehicleName){
        if(store.addVehicle(vehicleName)){
            return true;
        }
        return false;
    }

    public String findVehicle(int vehicelNo){
        return store.getVehicle(vehicelNo);
    }

    public boolean deleteVehicle(String name){
        return store.deleteVehicle(name);
    }
}
