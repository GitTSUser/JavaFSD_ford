package com.ford.mockito.subject;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.ford.mockito.service.CalculatorService;

public class MathApplicationTest {

	private MathApplication mathApp;

	@Before
	public void setUp() throws Exception {
		mathApp = new MathApplication();
	}

	@After
	public void tearDown() throws Exception {
		mathApp = null;
	}

	@Test
	public void testAddition() {

		CalculatorService cs = Mockito.mock(CalculatorService.class); // getting a mock of calculatorservice
		mathApp.setCalculatorService(cs); //setting mock to mathApp

		// add behavior of calculatorService to add two numbers
		Mockito.when(cs.add(100, 200)).thenReturn(300);

		int result = mathApp.addition(100, 200);

		assertEquals(300, result);

	}

	@Test
	public void testSubtraction() {
	}

	@Test
	public void testMultiplication() {
	}

}
