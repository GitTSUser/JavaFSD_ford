package com.ford.mockito.subject;

import com.ford.mockito.service.CalculatorService;

public class MathApplication {

	private CalculatorService calculatorService;

	public CalculatorService getCalculatorService() {
		return calculatorService;
	}

	public void setCalculatorService(CalculatorService calculatorService) {
		this.calculatorService = calculatorService;
	}

	public int addition(int num1, int num2) {

		return calculatorService.add(num1, num2);
	}

	public int subtraction(int num1, int num2) {
		return calculatorService.sub(num1, num2);
	}

	public int multiplication(int num1, int num2) {
		return calculatorService.mul(num1, num2);
	}
}
