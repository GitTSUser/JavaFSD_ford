package com.ford.mockito.service;

public interface CalculatorService {

	public int add(int num1, int num2);

	public int sub(int num1, int num2);

	public int mul(int num1, int num2);

}
