package com.ford.apps;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class AccountTest {

	private Account acnt;

	@Before
	public void setUp() {
		System.out.println("AccountTest.setUp()");
		acnt = new Account();
	}

	@Test
	public void testDeposit() {
		System.out.println("AccountTest.testDeposit()");
		acnt.deposit(1200);

		double actualBalance = acnt.getBalance();

		assertEquals(1200, actualBalance);
	}

	@Test
	public void testDepositMoreAmount() {

		System.out.println("AccountTest.testDepositMoreAmount()");
		double actualBalance = acnt.getBalance();

		acnt.deposit(2000);

		double currentBalance = actualBalance + 2000;

		assertEquals(actualBalance + 2000, currentBalance);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testDepositForNegativeAmount() {

		System.out.println("AccountTest.testDepositForNegativeAmount()");

		double actualBalance = acnt.getBalance();

		acnt.deposit(-1200);

		double currentBalance = actualBalance + -1200;

		assertEquals(actualBalance - 1200, currentBalance);

	}

	@After
	public void tearDown() {
		System.out.println("AccountTest.tearDown()");
		acnt = null;
	}

}