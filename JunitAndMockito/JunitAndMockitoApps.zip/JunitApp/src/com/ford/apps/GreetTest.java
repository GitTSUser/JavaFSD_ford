package com.ford.apps;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class GreetTest {

	@Test
	public void testGreet() {
		Greet g = new Greet("Hello, How are you?");

		String expectedResult = "Hello, How are you?";

		String actualResult = g.greet();

		assertEquals(expectedResult, actualResult);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testGreetWithNullAndException() {
		Greet g = new Greet(null);

		String expectedResult = null;

		String actualResult = g.greet();

		assertEquals(expectedResult, actualResult);
	}

}
