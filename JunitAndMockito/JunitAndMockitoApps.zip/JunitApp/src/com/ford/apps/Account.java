package com.ford.apps;

public class Account {

	private int balance;

	public int getBalance() {
		return this.balance;
	}

	public void deposit(int amount) {

		// amount can be a -ve amount , throw exception

		// amount can be a +ve amount, update balance

		// amount can be a +ve amount, update takes time

		// amount can be a 0 amount, update not required

		if (amount < 0) {

			throw new IllegalArgumentException("negative value is not allowed");
		}

		if (amount > 0) {
			this.balance = this.balance + amount;
			System.out.println("amount updated");
		}

		if (amount == 0) {
			System.out.println("update is not required");
		}

	}

}
