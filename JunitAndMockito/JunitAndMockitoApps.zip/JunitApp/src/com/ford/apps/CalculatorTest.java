
//program to demonstrate passing parameters dynamically to test method
package com.ford.apps;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.Collection;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

@RunWith(value = Parameterized.class)
public class CalculatorTest {

	private int num1;
	private int num2;
	private int result;

	public CalculatorTest(int num1, int num2, int result) {
		this.num1 = num1;
		this.num2 = num2;
		this.result = result;
	}

	@Parameters
	public static Collection<Integer[]> dynamicData() {

		// data to be injected to Test method stub
		Integer arr[][] = { { 20, 30, 50 }, { 100, 150, 250 }, { -20, -30, -50 }, { 50, -20, 30 } };

		return (Collection<Integer[]>) Arrays.asList(arr);

	}

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {

	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test(timeout = 1500)
	public void testAddition() {
		Calculator calculator = new Calculator();
		int actualResult = calculator.addition(num1, num2);
		System.out.println(num1 + " " + num2 + " : " + result);
		assertEquals(result, actualResult);
	}

	@Ignore
	public void testAdditionWithPositiveValues() {

	}

	@Ignore
	public void testAdditionWithNegativeValues() {

	}
}
