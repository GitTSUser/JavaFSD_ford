package com.ford.apps;

import static org.junit.Assert.assertEquals;

import org.junit.Ignore;
import org.junit.Test;

public class OperationsTest {

	@Test
	public void testAdd() {

		Operations ops = new Operations();

		int actualResult = ops.add(20, 20);

		assertEquals(40, actualResult);

	}

	@Ignore
	public void testAddWithNegativeValues() {

		Operations ops = new Operations();

		int actualResult = ops.add(-20, -20);

		assertEquals(-40, actualResult);
	}

	@Test
	public void testAddWithOneNegativeAndOnePositiveValues() {

		Operations ops = new Operations();

		int actualResult = ops.add(-20, 20);

		assertEquals(0, actualResult);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testAddWithZeros() {

		Operations ops = new Operations();

		int actualResult = ops.add(0, 0);

		assertEquals(0, actualResult);
	}

	@Ignore
	public void testSub() {

	}

}
