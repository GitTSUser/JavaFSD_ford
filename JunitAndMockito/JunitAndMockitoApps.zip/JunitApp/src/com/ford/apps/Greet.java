package com.ford.apps;

public class Greet {

	private String greeting;

	public Greet(String greeting) {
		this.greeting = greeting;
	}

	public String greet() {
		if (greeting != null) {
			System.out.println(greeting);

		} else {
			throw new IllegalArgumentException("null is not accepted");
		}
		return greeting;
	}

}
