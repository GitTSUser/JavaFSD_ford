package com.ford.apps;

import java.util.List;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

public class TestRunner {

	public static void main(String[] args) {

		Result result = JUnitCore.runClasses(GreetTest.class, OperationsTest.class);

		System.out.println("failures count is:" + result.getFailureCount());

		if (!result.wasSuccessful()) {
			List<Failure> failureList = result.getFailures();
			failureList.forEach(failure -> System.out.println("failure is:" + failure));
		}

		System.out.println("result is:" + result.wasSuccessful());

	}
}
