package com.ford.apps.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CustomerDto {
    private long adhaarNum;
    private String name;
    private double salary;
    private double loanProvided;
    private String loanIssuedOn;
}
