package com.ford.apps.service;


import com.ford.apps.dto.CustomerDto;

public interface ILoanService {

    public double issueLoan(double salary,double emi);

    public String saveCustomerInfo(CustomerDto customerDto);

}
