package com.ford.apps.service;

import com.ford.apps.dto.CustomerDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@Service
public class LoanServiceImpl implements ILoanService {

/*    @Autowired
    private RestTemplate restTemplate;*/

    @Autowired
    private WebClient webClient;

    @Override
    public double issueLoan(double salary, double emi) {

        //contact verifcationservice for loan issue
/*ResponseEntity<String> responseEntity = restTemplate
        .getForEntity("http://localhost:9091/VerifyService/verifyApplicant/" + salary + "/" + emi, String.class);
        String response = responseEntity.getBody();*/

        Mono<String> response=webClient.get().uri("http://localhost:9091/VerifyService/verifyApplicant/"+salary+"/"+emi)
                        .retrieve().bodyToMono(String.class);
        return Double.parseDouble(response.block());
    }

    @Override
    public String saveCustomerInfo(CustomerDto customerDto) {


        return webClient.post().uri("http://localhost:7071/CustomerService/customer",customerDto,String.class)
                .retrieve().bodyToMono(String.class).block();


    }
}
