package com.ford.apps.controller;

import com.ford.apps.dto.Applicant;
import com.ford.apps.dto.CustomerDto;
import com.ford.apps.service.ILoanService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;

@RestController
@RequestMapping("/api")
public class LoanController {

    @Autowired
    private ILoanService loanService;

    @PostMapping("/applyLoan")
    public String applyLoan(@RequestBody Applicant applicant){

        double loanAmount=loanService.issueLoan(applicant.getSalary(),applicant.getEmiAmount());

        if(loanAmount<0){
            return "Loan cannot be given as your application is rejected";
        }

        CustomerDto customerInfo=new CustomerDto(applicant.getAdhaarNum(),applicant.getName(),applicant.getSalary(),loanAmount, LocalDate.now().toString());

        loanService.saveCustomerInfo(customerInfo);


        return "Loan can be issued to you for the amount "+loanAmount;

    }


}
