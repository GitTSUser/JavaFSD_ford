package com.ford.apps.service;

import org.springframework.stereotype.Service;

@Service
public class VerificationServiceImpl implements IVerificationService {
    @Override
    public double verifyApplication(double salary, double emi) {

        double eligibleAmount = (3 * salary) - (36 * emi);
        return eligibleAmount;
    }
}
