package com.ford.apps.controller;

import com.ford.apps.service.IVerificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class VerificationController {

    @Autowired
    private IVerificationService verificationService;

    @GetMapping(path = "/verifyApplicant/{salary}/{emiAmount}")
    public ResponseEntity<Double> verifyLoan(@PathVariable("salary") double salary,@PathVariable("emiAmount") double emiAmount){
        double amount=verificationService.verifyApplication(salary,emiAmount);
        return new ResponseEntity<Double>(amount, HttpStatus.OK);
    }

}
