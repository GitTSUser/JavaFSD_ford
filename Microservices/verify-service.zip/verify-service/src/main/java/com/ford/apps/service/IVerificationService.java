package com.ford.apps.service;

public interface IVerificationService {

    public double verifyApplication(double salary,double emi);
}
