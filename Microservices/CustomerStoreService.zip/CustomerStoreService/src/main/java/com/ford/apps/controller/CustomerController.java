package com.ford.apps.controller;

import com.ford.apps.dto.CustomerDto;
import com.ford.apps.service.ICustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class CustomerController {

    @Autowired
    private ICustomerService customerService;

    @PostMapping(path = "/customer")
    public ResponseEntity<String> saveCustomerInfo(@RequestBody CustomerDto customerDto){

        if(customerService.addCustomer(customerDto)){
            return new ResponseEntity<String>("Customer details saved", HttpStatus.CREATED);
        }

        return new ResponseEntity<String>("Customer details not saved!",HttpStatus.NOT_ACCEPTABLE);
    }

}
