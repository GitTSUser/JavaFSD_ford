package com.ford.apps.service;

import com.ford.apps.dto.CustomerDto;

import java.util.List;

public interface ICustomerService {

    public boolean addCustomer(CustomerDto customerDto);

    public List<CustomerDto> getAllCustomers();
}
