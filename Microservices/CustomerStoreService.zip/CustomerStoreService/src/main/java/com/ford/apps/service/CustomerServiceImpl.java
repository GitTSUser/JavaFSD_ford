package com.ford.apps.service;

import com.ford.apps.dto.CustomerDto;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CustomerServiceImpl implements ICustomerService{

    private static List<CustomerDto> customerDtoList=new ArrayList<>();
    @Override
    public boolean addCustomer(CustomerDto customerDto) {
        customerDtoList.add(customerDto);
        return true;
    }

    @Override
    public List<CustomerDto> getAllCustomers() {
        return customerDtoList;
    }
}
