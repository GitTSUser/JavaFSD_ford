package com.ford.apps.service;


import com.ford.apps.dto.APIResponseDto;
import com.ford.apps.dto.EmployeeDto;

public interface EmployeeService {
    EmployeeDto saveEmployee(EmployeeDto employeeDto);
    APIResponseDto getEmployeeById(Long employId);
}