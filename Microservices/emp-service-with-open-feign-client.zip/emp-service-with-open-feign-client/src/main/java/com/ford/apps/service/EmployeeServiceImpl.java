package com.ford.apps.service;

import com.ford.apps.dto.APIResponseDto;
import com.ford.apps.dto.DepartmentDto;
import com.ford.apps.dto.EmployeeDto;
import com.ford.apps.entity.Employee;
import com.ford.apps.mapper.EmployeeMapper;
import com.ford.apps.repository.EmployeeRepository;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class EmployeeServiceImpl implements EmployeeService {

    private static final Logger LOGGER = LoggerFactory.getLogger(EmployeeServiceImpl.class);

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private APIClient apiClient;
/*    @Autowired
    private WebClient webClient;*/
    @Override
    public EmployeeDto saveEmployee(EmployeeDto employeeDto) {

        Employee employee = EmployeeMapper.mapToEmployee(employeeDto);

        Employee saveDEmployee = employeeRepository.save(employee);

        EmployeeDto savedEmployeeDto = EmployeeMapper.mapToEmployeeDto(saveDEmployee);

        return savedEmployeeDto;
    }

    @Override
    public APIResponseDto getEmployeeById(Long employId) {

        Employee employee=employeeRepository.findById(employId).get();

        DepartmentDto departmentDto=apiClient.getDepartment(employee.getDepartmentCode());

        /*System.out.println("employ details :"+employee);

        DepartmentDto departmentDto= webClient.get().uri("http://localhost:8081/DeptService/api/departments/"+employee.getDepartmentCode())
                .retrieve().bodyToMono(DepartmentDto.class).block();
        */
        EmployeeDto employeeDto=new EmployeeDto(employee.getId(),employee.getFirstName(),employee.getLastName(),employee.getEmail(),employee.getDepartmentCode());

        APIResponseDto apiResponseDto=new APIResponseDto();
        apiResponseDto.setEmployee(employeeDto);
        apiResponseDto.setDepartment(departmentDto);
        System.out.println("this method using openFeign client for rest calls");
        return apiResponseDto;
   }
}