package com.capg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppTwoApplicationTests {

	@Test
	void contextLoads() {
	}

}
