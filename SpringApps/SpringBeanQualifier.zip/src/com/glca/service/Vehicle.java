package com.glca.service;

public interface Vehicle {

	public void start();

	public void move();

	public void stop();
}
