package com.glca.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.glca.service.Vehicle;
import com.glca.service.VehicleAgent;

public class ClientApp {

	public static void main(String[] args) {

		ApplicationContext ctx = new ClassPathXmlApplicationContext("com/glca/resources/appConfig.xml");

		VehicleAgent agent = ctx.getBean(VehicleAgent.class);

		Vehicle vehicle = agent.getVehicle();

		vehicle.start();
		vehicle.move();
		vehicle.stop();

		((AbstractApplicationContext) ctx).registerShutdownHook();
	}
}
