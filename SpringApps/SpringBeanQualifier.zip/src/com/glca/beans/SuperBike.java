package com.glca.beans;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.glca.service.Vehicle;

@Component("superBike")
public class SuperBike implements Vehicle {

	@Value("222")
	private int id;

	@Value("RoyalEnfield")
	private String name;

	@Override
	public void start() {

		System.out.println("superbike started");
	}

	@Override
	public void move() {

		System.out.println("riding on super");

	}

	@Override
	public void stop() {
		System.out.println("superbike stopped");
	}

}
