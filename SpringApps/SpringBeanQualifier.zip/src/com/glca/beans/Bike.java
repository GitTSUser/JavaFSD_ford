package com.glca.beans;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.glca.service.Vehicle;

@Component("bike")
public class Bike implements Vehicle {

	@Value("111")
	private int id;

	@Value("Splendor")
	private String name;

	@Override
	public void start() {
		System.out.println("Bike started.");
	}

	@Override
	public void move() {

		System.out.println("riding on bike");

	}

	@Override
	public void stop() {

		System.out.println("Bike stopped");

	}

}
