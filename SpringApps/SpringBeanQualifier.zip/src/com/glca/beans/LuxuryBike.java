package com.glca.beans;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.glca.service.Vehicle;

@Component("luxuryBike")
public class LuxuryBike implements Vehicle {

	@Value("333")
	private int id;

	@Value("OlaBike")
	private String name;

	@Override
	public void start() {
		System.out.println("LuxuryBike started");
	}

	@Override
	public void move() {

		System.out.println("riding on luxury");

	}

	@Override
	public void stop() {
		System.out.println("LuxuryBike stopped");
	}

}
