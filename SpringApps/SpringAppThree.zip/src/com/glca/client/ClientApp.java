package com.glca.client;

import java.util.Set;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.glca.beans.Course;
import com.glca.beans.Student;

public class ClientApp {

	public static void main(String[] args) {

		ApplicationContext ctx = new ClassPathXmlApplicationContext("com/glca/resources/appConfig.xml");

		Student st = ctx.getBean("s1", Student.class);

		System.out.println(st.getId() + " " + st.getName());

		System.out.println("Courses:");

		st.getCourses().forEach(course -> System.out.println(course+"  "+course.getTechnologies()));

		((AbstractApplicationContext) ctx).close();

	}

}
