package com.glca.beans;

import java.util.List;

public class Course {

	private int cno;
	private String cname;
	private double fee;
	private List<String> technologies;

	public Course(int cno, String cname, double fee) {
		System.out.println("Course.Course()");

		this.cno = cno;
		this.cname = cname;
		this.fee = fee;
	}

	public int getCno() {
		return cno;
	}

	public void setCno(int cno) {
		this.cno = cno;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public double getFee() {
		return fee;
	}

	public void setFee(double fee) {
		this.fee = fee;
	}

	@Override
	public String toString() {
		return "Course [cno=" + cno + ", cname=" + cname + ", fee=" + fee + "]";
	}

	public List<String> getTechnologies() {
		return technologies;
	}

	public void setTechnologies(List<String> technologies) {
		System.out.println("Course.setTechnologies()");
		this.technologies = technologies;
	}

}
