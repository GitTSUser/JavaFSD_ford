package com.glca.beans;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Test {

	@Value("111")
	private int id;

	@Value("Maths")
	private String name;

	@Value("80")
	private int score;

	public Test() {
		System.out.println("Test.Test()");
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	@Override
	public String toString() {
		return "Test [id=" + id + ", name=" + name + ", score=" + score + "]";
	}

}
