package com.glca.client;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.glca.beans.Student;
import com.glca.beans.Test;

public class ClientApp {

	public static void main(String[] args) {

		ApplicationContext ctx = new ClassPathXmlApplicationContext("com/glca/resources/appConfig.xml");

		Student s = ctx.getBean("st", Student.class);

		System.out.println(s);

		List<String> courses = s.getCourses();

		courses.forEach(course -> System.out.println(course));

		Test t = s.getTest();

		System.out.println(t);
		
		((AbstractApplicationContext) ctx).close();

	}

}
