package com.glca.bean;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.FileSystemResource;

public class Client {
	public static void main(String[] args) {
		BeanFactory factory=new XmlBeanFactory(
				new FileSystemResource("src/com/glca/resources/beanConfig.xml"));
		Hospital hospital=(Hospital) factory.getBean("hospital");
		
		System.out.println(hospital);
		
		Doctor doc=hospital.getDoctor();
		System.out.println(doc);
		
	}
}
