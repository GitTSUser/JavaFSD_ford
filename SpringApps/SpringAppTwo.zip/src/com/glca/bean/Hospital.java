package com.glca.bean;

public class Hospital {

	private int regNo;
	private String name;
	private Doctor doctor;

	@Override
	public String toString() {
		return "Hospital [regNo=" + regNo + ", name=" + name + ", doctor=" + doctor + "]";
	}

	public int getRegNo() {
		return regNo;
	}

	public void setRegNo(int regNo) {
		this.regNo = regNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Doctor getDoctor() {
		return doctor;
	}

	public void setDoctor(Doctor doctor) {
		this.doctor = doctor;
	}

}
