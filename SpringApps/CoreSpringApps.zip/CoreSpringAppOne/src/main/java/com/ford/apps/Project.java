package com.ford.apps;

public class Project {
    private int pid;
    private String name;
    private String manager;

    public Project(int pid, String name, String manager) {
        System.out.println("Project.Project() constructor called");
        this.pid = pid;
        this.name = name;
        this.manager = manager;
    }

    @Override
    public String toString() {
        return "Project{" + "pid=" + pid + ", name='" + name + '\'' + ", manager='" + manager + '\'' + '}';
    }
}
