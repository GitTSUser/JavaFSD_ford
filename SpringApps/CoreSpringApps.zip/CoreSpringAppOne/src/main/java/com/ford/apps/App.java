package com.ford.apps;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

/**
 * Hello world!
 */
public class App {
    public static void main(String[] args) {

        // creating a ioc container by passing beanconfiguration file
        ApplicationContext applicationContext = new FileSystemXmlApplicationContext("src/main/resources/beanConfig.xml");

        Employ employ = (Employ) applicationContext.getBean("emp"); //asking ioc container to give bean object

        System.out.println("employ id:" + employ.getId());
        System.out.println("employ name:" + employ.getName());
        System.out.println("employ salary:" + employ.getSalary());

        //Project project=(Project)applicationContext.getBean("proj");
        Project project=employ.getProject();

        System.out.println("project details:"+project);

        Object obj=applicationContext.getBean("emp2");

        Employ employ2=(Employ) obj;


        System.out.println("employ2 details:"+employ2);
        employ2.setName("Sushmitha");
        System.out.println("employ2 details:"+employ2);

        Hotel hotel=applicationContext.getBean("hotel", Hotel.class);

        System.out.println("Hotel name:"+hotel.getName());
        System.out.println("Hotel visitors:");
        hotel.getVisitors().forEach(visitor-> System.out.println(visitor));

    }
}
