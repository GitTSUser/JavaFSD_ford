package com.ford.apps;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class AppTwo {

    public static void main(String[] args) {

        ApplicationContext applicationContext=new FileSystemXmlApplicationContext("src/main/resources/beanConfig.xml" );

        Employ emp=applicationContext.getBean("emp",Employ.class);

        System.out.println(emp.hashCode());

        Employ emp2=applicationContext.getBean("emp",Employ.class);

        System.out.println(emp2.hashCode());

        if(emp.hashCode()==emp2.hashCode()){
            System.out.println("both are same");
        }else{
            System.out.println("both are different");
        }

    }
}
