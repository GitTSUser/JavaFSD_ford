package com.ford.apps;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

/**
 * Hello world!
 */
public class App {
    public static void main(String[] args) {

        ApplicationContext applicationContext=new FileSystemXmlApplicationContext("src/main/resources/beansConfig.xml");
        Hospital hospital=applicationContext.getBean("hosp",Hospital.class);

        hospital.getDoctors().forEach(doctor -> System.out.println(doctor));


         }
}
