package com.ford.apps;

import java.util.Set;

public class Hospital {

    private int regNo;
    private String name;
    private Set<Doctor> doctors;

    public Hospital() {
    }

    public Hospital(int regNo, String name, Set<Doctor> doctors) {
        this.regNo = regNo;
        this.name = name;
        this.doctors = doctors;
    }

    public int getRegNo() {
        return regNo;
    }

    public void setRegNo(int regNo) {
        this.regNo = regNo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set<Doctor> getDoctors() {
        return doctors;
    }

    public void setDoctors(Set<Doctor> doctors) {
        this.doctors = doctors;
    }
}


