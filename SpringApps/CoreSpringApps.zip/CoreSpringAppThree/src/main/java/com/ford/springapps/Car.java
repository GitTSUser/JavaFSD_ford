package com.ford.springapps;

import org.springframework.stereotype.Component;

@Component("car")
public class Car implements  Vehicle{

    @Override
    public void startVehicle() {
        System.out.println("Car Started");
    }

    @Override
    public void travel(String from, String to) {
        System.out.println("travelling from "+from+" to "+to);
    }

    @Override
    public void stopVehicle() {
        System.out.println("Car stopped");

    }

}
