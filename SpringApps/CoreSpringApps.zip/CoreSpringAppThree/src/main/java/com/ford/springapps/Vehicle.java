package com.ford.springapps;

public interface Vehicle {

    public void startVehicle();
    public void travel(String from,String to);
    public void stopVehicle();
}
