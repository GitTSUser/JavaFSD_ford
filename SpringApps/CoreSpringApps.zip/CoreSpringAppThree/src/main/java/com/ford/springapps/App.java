package com.ford.springapps;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        ApplicationContext applicationContext=new FileSystemXmlApplicationContext("src/main/resources/beanConfig.xml");

        Product product=applicationContext.getBean("prod",Product.class);

        System.out.println("-----Product Details------");
        System.out.println(product.getId()+" "+product.getName()+" "+product.getPrice()+" "+product.getQty());

        System.out.print("Deliver product at: ");
        System.out.println(product.getDeliveryAddress());




    }
}
