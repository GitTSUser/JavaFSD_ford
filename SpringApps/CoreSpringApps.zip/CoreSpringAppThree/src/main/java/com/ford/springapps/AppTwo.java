package com.ford.springapps;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class AppTwo {
    public static void main(String[] args) {

        ApplicationContext applicationContext=new FileSystemXmlApplicationContext("src/main/resources/beanConfig.xml" );

        VehicleAgent vehicleAgent=applicationContext.getBean(VehicleAgent.class);

        Vehicle vehicle=vehicleAgent.getVehicle();

        vehicle.startVehicle();
        vehicle.travel("Chennai","Hyderabad");
        vehicle.stopVehicle();
    }
}
