package com.ford.springapps;

import org.springframework.stereotype.Component;

@Component("bike")
public class Bike implements  Vehicle{
    @Override
    public void startVehicle() {
        System.out.println("Bike Started");
    }

    @Override
    public void travel(String from, String to) {
        System.out.println("travelling from "+from+" to "+to);
    }

    @Override
    public void stopVehicle() {
        System.out.println("Bike stopped");

    }
}
