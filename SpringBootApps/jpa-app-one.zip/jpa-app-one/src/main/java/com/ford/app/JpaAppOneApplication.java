package com.ford.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaAppOneApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpaAppOneApplication.class, args);
	}

}
