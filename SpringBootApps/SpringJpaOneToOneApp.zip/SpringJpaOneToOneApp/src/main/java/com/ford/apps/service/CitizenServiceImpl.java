package com.ford.apps.service;

import com.ford.apps.entity.Citizen;
import com.ford.apps.repository.ICitizenRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@Slf4j
public class CitizenServiceImpl implements  ICitizenService{

    @Autowired
    private ICitizenRepository citizenRepository;
    @Override
    public Citizen addCitizen(Citizen citizen) {
       log.info("addCitizen(Citizen citizen) method starts");
          citizenRepository.save(citizen);
        log.info("addCitizen(Citizen citizen) method ends");
        return citizen;
    }

    @Override
    public Citizen getCitizen(Long adhaar) {
        log.info("getCitizne(Long adhaar) method starts");
        Optional<Citizen> optionalCitizen=citizenRepository.findById(adhaar);
        Citizen citizen=null;
            if(optionalCitizen.isPresent()){
                citizen=optionalCitizen.get();
            }
        log.info("getCitizne(Long adhaar) method ends");
        return citizen;
    }

    @Override
    public List<Citizen> getAllCitizen() {
        log.info("getAllCitizen() method starts");
        List<Citizen> citizenList=citizenRepository.findAll();
        log.info("getAllCitizen() method ends");

        return citizenList;
    }

    @Override
    public Citizen getCitizenByName(String citizenName) {
        log.info("getCitizenByName(String citizenName) method starts");
        Citizen citizen= citizenRepository.findByName(citizenName);
        log.info("getCitizenByName(String citizenName) method ends");
        return citizen;
    }

    @Override
    public Citizen getCitizenByPhoneNoAndName(String phone, String name) {
        log.info("getCitizenByPhoneNoAndName(String phone, String name) method starts");

        Citizen citizen=citizenRepository.findByPhoneAndName(phone,name);
        log.info("getCitizenByPhoneNoAndName(String phone, String name) method ends");
        return citizen;
    }

    @Override
    public Citizen updateCitizen(Citizen citizen) {
        log.info("updateCitizen(Citizen citizen) method starts");
        citizenRepository.save(citizen);
        log.info("updateCitizen(Citizen citizen) method ends");

        return citizen;
    }

    @Override
    public boolean deleteCitizen(Long adhaar) {

        log.info("deleteCitizen(Long adhaar) method starts");
        citizenRepository.deleteById(adhaar);
        log.info("deleteCitizen(Long adhaar) method ends");
        return true;
    }
}