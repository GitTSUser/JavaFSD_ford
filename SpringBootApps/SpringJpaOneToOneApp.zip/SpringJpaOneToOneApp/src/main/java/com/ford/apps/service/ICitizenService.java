package com.ford.apps.service;

import com.ford.apps.entity.Citizen;

public interface ICitizenService {

    public Citizen addCitizen(Citizen citizen);
    public Citizen getCitizen(Long adhaar);
    public java.util.List<Citizen> getAllCitizen();
    public Citizen getCitizenByName(String citizenName);
    public Citizen getCitizenByPhoneNoAndName(String phone,String name);

    public Citizen updateCitizen(Citizen citizen);

    public boolean deleteCitizen(Long adhaar);

}
