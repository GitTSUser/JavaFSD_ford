package com.ford.apps.entity;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Data
@AllArgsConstructor
@Entity
@Table(name="passports")
@NoArgsConstructor
public class Passport {

    @Id
    private Integer pno;
    private String nationality;
    private String validFrom;
    private String validTo;

}
