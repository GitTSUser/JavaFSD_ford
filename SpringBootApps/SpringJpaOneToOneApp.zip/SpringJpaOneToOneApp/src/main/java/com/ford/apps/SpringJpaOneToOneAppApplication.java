package com.ford.apps;

import com.ford.apps.entity.Citizen;
import com.ford.apps.entity.Passport;
import com.ford.apps.service.ICitizenService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@Slf4j
public class SpringJpaOneToOneAppApplication  implements CommandLineRunner {

    @Autowired
    private ICitizenService citizenService;

    public static void main(String[] args) {

        SpringApplication.run(SpringJpaOneToOneAppApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {

            //adding citizen and passport details
             addCitizenDetailsIntoDB();

             //get citizen details to display
            displayCitizendetailsFromDB();
    }


    public void addCitizenDetailsIntoDB(){

        Passport passport=new Passport(10000,"Indian","29-Feb-2024","29-Feb-2029");

        Citizen citizen=new Citizen(123456789L,"Raaman","044-22334456",passport);


        Passport passport2=new Passport(20000,"Australan","29-Feb-2024","29-Feb-2029");

        Citizen citizen2=new Citizen(123456799L,"ShaneWarne","044-22334456",passport2);


        Passport passport3=new Passport(30000,"USA","29-Feb-2024","29-Feb-2029");

        Citizen citizen3=new Citizen(123456699L,"Mike","044-22334456",passport3);

        Citizen savedCitizen=citizenService.addCitizen(citizen);
        Citizen savedCitizen2=citizenService.addCitizen(citizen2);
        Citizen savedCitizen3=citizenService.addCitizen(citizen3);

        log.info("Saved Citizen-1 details are:{}",savedCitizen);
        log.info("Saved Citizen-2 details are:{}",savedCitizen2);
        log.info("Saved Citizen-3 details are:{}",savedCitizen3);

    }

    public void displayCitizendetailsFromDB(){

        log.info("--------------All Citizens Details -----------");
        citizenService.getAllCitizen().forEach(citizen -> System.out.println(citizen));

    }

}
