package com.ford.apps.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@AllArgsConstructor
@Entity
@Table(name="citizens")
@NoArgsConstructor
public class Citizen {

    @Id
    private Long adhaar;
    private String name;
    private String phone;

    @OneToOne(cascade = CascadeType.ALL,fetch = FetchType.EAGER)
    private Passport passport;
}
