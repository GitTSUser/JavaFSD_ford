package com.ford.apps.repository;

import com.ford.apps.entity.Citizen;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ICitizenRepository extends JpaRepository<Citizen,Long> {
    Citizen findByName(String citizenName);

    Citizen findByPhoneAndName(String phone, String name);
}
