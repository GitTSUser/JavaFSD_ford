package com.hcl.mappings.entities;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

import lombok.Data;

@Entity
@Data
public class Course {

	@Id
	private int id;

	private String name;

	@ManyToMany(fetch = FetchType.LAZY, mappedBy = "courses")
	private Set<Student> students;

	@OneToMany(mappedBy = "course")
    Set<CourseRating> ratings;
}
