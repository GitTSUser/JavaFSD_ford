package com.hcl.mappings.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.hcl.mappings.entities.Student;
import com.hcl.mappings.repos.IStudentRepo;

@Service
@Transactional
public class StudentServiceImpl implements IStudentService {
		
	@Autowired
	private IStudentRepo studentRepo;

	@Override
	public Student addStudent(Student student) {
		return studentRepo.save(student);
	}

	@Override
	public Student upadateStudent(Student student) {
		return studentRepo.save(student);
	}

	@Override
	public Student retreiveStudent(int id) {
		return studentRepo.getById(id);
	}

	@Override
	public List<Student> retreiveAllStudents() {
		Sort sort=Sort.by("name");
		return studentRepo.findAllStudents(sort);
	}

	@Override
	public List<Student> sortedStudentsByName() {
		Sort sort=Sort.by("name");
		
		return studentRepo.findAll(sort);
	}

}
