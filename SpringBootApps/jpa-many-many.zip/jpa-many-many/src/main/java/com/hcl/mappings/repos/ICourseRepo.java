package com.hcl.mappings.repos;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hcl.mappings.entities.Course;

@Repository
public interface ICourseRepo extends JpaRepository<Course, Integer>{

}
