package com.hcl.mappings.services;

import java.util.List;

import com.hcl.mappings.entities.Student;

public interface IStudentService {

	public Student addStudent(Student student);

	public Student upadateStudent(Student student);

	public Student retreiveStudent(int id);

	public List<Student> retreiveAllStudents();

	public List<Student> sortedStudentsByName();

}
