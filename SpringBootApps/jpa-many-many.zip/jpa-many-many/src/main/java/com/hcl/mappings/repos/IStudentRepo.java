package com.hcl.mappings.repos;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hcl.mappings.entities.Student;

@Repository
public interface IStudentRepo extends JpaRepository<Student, Integer>{	
	
	@Query(value = "SELECT u FROM Student u")
	List<Student> findAllStudents(Sort sort);

}