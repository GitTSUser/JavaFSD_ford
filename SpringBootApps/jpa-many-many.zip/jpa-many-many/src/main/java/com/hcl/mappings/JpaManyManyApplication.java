package com.hcl.mappings;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaManyManyApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpaManyManyApplication.class, args);
	}

}
