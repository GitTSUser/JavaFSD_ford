package com.ford.apps.service;

import com.ford.apps.entity.Company;
import java.util.List;
public interface ICompanyService {

    public Company addCompany(Company company);
    public List<Company> getAllCompanies();
    public Company getCompany(int companyId);



}
