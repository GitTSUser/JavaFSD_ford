package com.ford.apps;

import com.ford.apps.entity.Company;
import com.ford.apps.entity.Employ;
import com.ford.apps.service.ICompanyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.HashSet;
import java.util.Set;

@SpringBootApplication
public class JpaAppOneToManyDemoApplication implements CommandLineRunner {

    @Autowired
    private ICompanyService companyService;

    public static void main(String[] args) {
        SpringApplication.run(JpaAppOneToManyDemoApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {

        saveCompanyInfoIntoDatabase();

    }

    private void saveCompanyInfoIntoDatabase() {

        Employ e1 = new Employ(1001, "arun", 4500.25);
        Employ e2 = new Employ(100, "varun", 5500.25);
        Employ e3 = new Employ(1003, "tarun", 6500.25);
        Set<Employ> employSet = new HashSet<>();
        employSet.add(e1);
        employSet.add(e2);
        employSet.add(e3);

        Company company = new Company(12345, "Ford", "Perumbakkam", employSet);

        companyService.addCompany(company);
        System.out.println("company details added in db");

    }
}
