//program to demonstrate arrow functions

/*function add(a,b) {
    return a+b;
}*/

const add=(a,b)=>{
    return a+b;
}



const result=add(200,30);

console.log("result is:",result)


//arrow functions can be passed as argument to other functions


//findout even numbers in the given array using arrow function

const nums=[40,12,15,13,23]; //a number array

const findEven=(num)=>{  // a arrow function that takes num as input and return true/false
    if(num%2==0){
        return true;
    }
    return false;
};

function countEvenNumbers(numArray,arrowFun){
    let cnt=0;
    for (const num of numArray) {
        if(arrowFun(num)){
            cnt++;
        }
    }
    return cnt;
}

const evenCount=countEvenNumbers(nums,findEven)
console.log("Even Numbers count is:",evenCount)
