//program to demonstrate a function expression

const sum=function(x,y) {
    return x+y;
};

const mul=function(x,y){
    return x*y;
};


const result=sum(200,100)-mul(10,20);

console.log("result is:",result)