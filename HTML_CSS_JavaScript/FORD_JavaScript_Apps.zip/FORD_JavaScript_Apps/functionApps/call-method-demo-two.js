//program to demo call method using for passing args and changing context

function  Product(){ //this is constrctor function

    this.id=1001,
    this.name='fan',
    this.price=4500.20,

    this.productInfo= function(discount,quantity){
        console.log("this points to ::",this)
        console.log(`Product id: ${this.id} name: ${this.name} price: ${this.price}`);
        console.log(`Discount is:${discount} and qunatity is: ${quantity}`);
    },

    this.actualPrice= function(discount){

        return this.price-discount;
    }
}


let p1=new Product();
p1.productInfo(20.25,10);
console.log("Acutal price is:",p1.actualPrice(500));

let anotherProduct= {

    id:1002,
    name:'fan',
    price:'6500.25',
    discount:250.25,
    qty:5
};

p1.productInfo.call(anotherProduct,anotherProduct.discount,anotherProduct.qty);




