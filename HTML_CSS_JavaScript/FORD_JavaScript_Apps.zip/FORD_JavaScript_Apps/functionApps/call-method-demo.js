//program to demo call method improving the capabilities of a function
//program demos on changing context of Person to AnotherPerson or String

function Person(){  //constuctor function is used for obj creation

    this.name='arun',
    this.saySomething=function(){
        console.log("this points to:",this)
    console.log(`Hello How are you ${this.name}`)
    }
}

let p1=new Person();
p1.saySomething();


function AnotherPerson(){ //constructor fun
    this.name='Sumanth'
}

let ap1=new AnotherPerson();

p1.saySomething.call(ap1);

p1.saySomething.call("ashok")


