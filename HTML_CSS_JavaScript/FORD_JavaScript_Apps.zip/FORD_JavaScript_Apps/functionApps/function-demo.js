//program to demonstrate function declaration and calling it

function wish() {

    console.log("Hi! Good evening");
    
}

wish();
wish();


//function takes args

function findNoOfChars(cityName){

    console.log(cityName+" has "+cityName.length+" chars");
}

findNoOfChars("Chennai");
findNoOfChars("Hyderabad");


//function takes multiple args and returns value

function getFullName(firstName,lastName) {
    
    return firstName+"-"+lastName;
}

const fullName= getFullName("Sachin","Tendulkar")

console.log("full name is:",fullName)



//function takes name of person and print that name N times


function printName(name,noOfTimes) {


    for(let i=1;i<=noOfTimes;i++){
        console.log(i+") "+name)
    }    
}

printName("Raja",6);
