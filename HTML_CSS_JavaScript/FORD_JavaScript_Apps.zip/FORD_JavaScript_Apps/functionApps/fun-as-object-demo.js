//program to prove that a function is also an object in JavaScript

function saySomething() {

    console.log("Welcome to programming in JavaScript")
    
}

saySomething();

console.log(typeof saySomething);

console.log(saySomething instanceof Object)

saySomething.x=100;

console.log(saySomething.x)

console.log(saySomething.prototype);


saySomething=function(){
    console.log("Hello, I am new welcome")
}

saySomething();