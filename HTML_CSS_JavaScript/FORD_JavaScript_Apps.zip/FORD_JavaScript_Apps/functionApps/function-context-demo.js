//program to demonstrate function context

//this variable points to global context
function thisWithGlobalContext(){

    console.log(this);
    console.log("what is the typeof this:"+typeof this);
}

thisWithGlobalContext();


// this variable points to person context
var person={
    name:"arun",

    getName: function(){
        console.log("called : ",this);
        console.log(typeof this)
    }
};

person.getName();


var pname=person.getName;

console.log(pname==person.getName)
