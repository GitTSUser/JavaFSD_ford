//program to demonstrate fun as first class citizen , i.e., a fun can be passed as argument
//to another function

function add(x,y){
    console.log("sum is:",x+y)
}

function mul(x,y){
    console.log("mul is:",x*y)
}


function operate(x,y, operation){

    operation(x,y);
}



operate(20,30,mul)