//program to demo the use of bind method on a function
// bind method copies/binds a function for another object and that can be called later

function Employ(eid,ename,esalary){

    this.id=eid,
    this.name=ename,
    this.salary=esalary,
    this.employInfo=function(){
        console.log(`Employ info: ${this.id} ${this.name}  ${this.salary} `)
    }
}

let e1=new Employ(1001,'ArunKumar',65000.25);

e1.employInfo();


const product={
    id:1234,
    name:'fan',
    price:4500.25
}


const prodInfo=e1.employInfo.bind(product); // the bind method binds the employInfo() function of e1 to product

prodInfo(); //calling the binded method here for product

