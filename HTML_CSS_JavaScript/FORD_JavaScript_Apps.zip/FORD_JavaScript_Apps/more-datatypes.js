//program to demonstrate variables initialization details

var  city;

console.log("city is:",city,typeof city);

city="Chennai";

console.log("city is:"+city,typeof city);