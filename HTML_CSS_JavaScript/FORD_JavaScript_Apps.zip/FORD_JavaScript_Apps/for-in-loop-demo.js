// program to demo the use of for-in-loop.

const employ={
    id:1001,
    name:"arun",
    salary:45600,
    role:"developer",
    email:"arun@yahoo.com"
};

//console.log(employ);

//console.log("employ name:",employ.name)
//console.log("employ salary:",employ.salary)

for (const e in employ) {    
    console.log(employ[e])
}