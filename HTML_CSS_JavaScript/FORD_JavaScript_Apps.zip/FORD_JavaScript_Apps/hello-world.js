// program to print a hello world message

console.log("Welcome to JavaScript programming");