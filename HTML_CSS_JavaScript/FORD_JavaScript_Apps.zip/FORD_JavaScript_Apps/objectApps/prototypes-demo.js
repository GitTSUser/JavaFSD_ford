//program to demo object prototype

var  myObj={
    x:100
}

console.log(myObj)

console.log(Object.getPrototypeOf(myObj))
console.log(myObj.__proto__)

Object.setPrototypeOf(myObj,{y:200});

console.log(Object.getPrototypeOf(myObj))

console.log(myObj.__proto__)
