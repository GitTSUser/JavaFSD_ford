//program to demonstrate object creation

const employ={
    id:1001,
    name:"arun",
    salary:45000.23
}

console.log(employ);


//object creation using constructor function

function Product(id,name,price){

    console.log("inside Product "+this)
    this.id=id;
    this.name=name;
    this.price=price;
    this.productInfo=function(){
        console.log("inside productInfo "+this)
        console.log(this.id+" "+this.name+" "+this.price)
    }
}

const p1= new Product(1001,"fan",45000.25);

const p2=new Product(1002,"lappy",65000.25);

p1.productInfo();


//creation of object in another way

const vehicle=new Object();

console.log(vehicle)

vehicle.regNo=1234;
vehicle.name="BMW car";
vehicle.speed=120;

for (const v in vehicle) {
  
    console.log(v+" : "+vehicle[v])
}

//object prototype can be displayed

let cars=["BMW","CRETA","MAHINDRA","HUNDAI"];


console.log(cars);




console.log(Object.getPrototypeOf(cars));

console.log(Array.prototype)
console.log(cars.__proto__ === Array.prototype);
console.log(cars.__proto__ === employ.prototype);



























































