//program to demonstrate use of prototype on objects

function Item(itemCode,itemName,itemPrice) {

    this.itemCode=itemCode;
    this.itemName=itemName;
    this.itemPrice=itemPrice;
    
}

const i1=new Item(1234,"item-1",400.25);
const i2=new Item(1235,"item-2",600.26);


console.log(i1)
Item.prototype.itemQuality="Medium"; //adds a common property to all objects

Item.prototype.displayItemInfo= function(){ //adds a common functionality to all objects
    console.log(this.itemCode+" "+this.itemName+" "+this.itemPrice);
}
//i1.itemQuality="Medium";
//console.log(i1.itemQuality)
//console.log(i2.itemQuality);

//console.log(Object.getOwnPropertyNames(i1))
//console.log(Item.prototype)
//console.log(Item.prototype.prototype)

i1.displayItemInfo();
i2.displayItemInfo();







