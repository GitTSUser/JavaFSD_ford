//program to demonstrate diff types of operators

//arithmetic operations

var a=200;
var b=100;

console.log("a+b is:",a+b);
console.log("a-b is:",a-b);
console.log("a*b is:",a*b);
console.log("a/b is:",a/b);
console.log("a%b is:",a%b);

//relational operations
console.log("--------Relational Oprations---")
console.log("a>b is:",a>b)
console.log("a<b is:",a<b)
console.log("a==b is:",a==b);
console.log("a===b is:",a===b);
console.log("a!=b is:",a!=b);

//logical operations used for evaulating expressions
//logical operators AND,OR,NOT

let x=12,y=20,z=35;

console.log("-------Logical Operations------")
console.log("x>=y && y==z is:",(x>=y) && (y==z));
console.log("x>=y || y==z is:",(x>=y) || (y==z));
console.log("!(x==y) is:",!(x==y))


//string operators

let soap="San";
let soap2="Santoor";

console.log(" soap>soap2 is:", soap>soap2);
console.log(" soap<soap2 is:",soap<soap2);