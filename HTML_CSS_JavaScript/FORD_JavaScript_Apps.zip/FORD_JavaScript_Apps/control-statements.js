//program to demo conditional control statements

let age = 24;

if (age > 18) {
  console.log("eligible to vote");
} else {
  console.log("not eligible to vote");
}

//if_else if...else statement

const currentHour = new Date().getHours();
console.log("Current hour is:", currentHour);
if (currentHour <= 11) {
  console.log("Good Morning");
} else if (currentHour > 12 && currentHour <= 14) {
  console.log("Good afternoon");
} else if (currentHour > 14 && currentHour <= 18) {
  console.log("Good Evening");
} else {
  console.log("Good night");
}

//switch demo
console.log("----------Color---------");
let color = "ALMONDE";
color="PURPLE"
switch (color.length) {
  case 3:
    console.log("choosen color is of 3 chars");
    break;
  case 5:
    console.log("choosen color is of 5 chars");
    break;

  case 7:
    console.log("choosen color is of 7 chars");
    break;

  default:
    console.log("you have chosen color of your own choice");
}
