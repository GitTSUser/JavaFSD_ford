//program to demonstrate operations on array

let fruits=new Array("orange","banana","mango","watermelon");

console.log(fruits)

let flowers= ["lilly","jasmin","rose"];

console.log(flowers)

flowers.push("Lavender")
flowers.push("Marigold")

console.log(flowers)
console.log("no.of flowers:",flowers.length)
console.log("2nd flower is:",flowers[2])
console.log("last flower to remove is:"+flowers.pop());
flowers.unshift("SilverRose")
console.log(flowers)
flowers.shift();
console.log(flowers)

console.log(fruits)

let slicedFruits= fruits.slice(1,3);
console.log("extracted from fruits are:",slicedFruits)

console.log(fruits);
fruits.splice(1,1,"Kiwi","JackFruit");
console.log("after splice , fruits are:",fruits)


flowers.forEach(f=> console.log("Flower is:",f))