//program to demo use of for-of-loop

let cars=["BMW","Skoda","Creta","Mahindra"]

for (const car of cars) {

    console.log("Car is:",car)
    
}


//findout in howmany subjects, student got more than 50 marks
let marks=[50,45,86,52,65,42];

let count=0;

for (const mark of marks) {

    if(mark>=50){
        count++;
    }   
}
console.log("got marks morethan 50 in subjects:",count)


//loop over a string

let stmt="All that Glitters is not Gold";

for (const ch of stmt) {
    
    let unicode=ch.charCodeAt(0);

    if(unicode>=65 && unicode<=90){
        console.log("uppercase letter is:",ch);
    }

}







