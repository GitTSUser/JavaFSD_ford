//program to print nums between 1 to 10

for(let i=1;i<=10;i++){
    console.log("Num is:",i);
}

//print nums in reverse order
console.log("====reverse order-=====")
for(let i=10;i>=1;i--){
    console.log("Num is:",i)
}