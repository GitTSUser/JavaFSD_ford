//program to demo return a function as argument (first class citizen)

function generateCardNumber() {

    return function newCardNumber() {
        return Math.random();
    };  
}

var cardNum=generateCardNumber();

console.log("returned function is:",cardNum)
console.log("Card number is:",cardNum());