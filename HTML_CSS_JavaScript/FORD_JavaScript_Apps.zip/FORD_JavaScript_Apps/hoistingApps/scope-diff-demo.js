//program to demo scope differences with var and let keywords

var name="arun";

function findAge(yearOfBirth){

    let currentYear=new Date().getFullYear();

   const age= currentYear-yearOfBirth;

   function printPersonInfo() {
    console.log("Name is:",name) //access to var variable(global)
    console.log("Current year is:",currentYear) //access to outer function variable
    console.log("age is:",age); //access to outer function variable
   }

   printPersonInfo()
}

console.log("name is:",name);
findAge(2012);
//console.log("outside fun,current year is:",currentYear)
//console.log("outside fun,age is:",age);