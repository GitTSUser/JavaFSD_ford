//program to demonstrate variable hoisting
//here varible x declaration is moved to top(hoisted) and var variable can be accessed without 
//initialization
console.log("x - is:",x)
var x=200;
console.log("x is:",x)


//here, let variable y is moved to top(hoisted) but let variable can not be allowed to be
//accessed or used without initialization

console.log("y is:",y);
let y=300;
console.log("y is:",y)


//here, const variable z is moved to top(hoisted) but const variable cannot be 
//allowed to be accessed or used without initialization

console.log("z is:",z);
const z=300;
console.log("z is:",z)

