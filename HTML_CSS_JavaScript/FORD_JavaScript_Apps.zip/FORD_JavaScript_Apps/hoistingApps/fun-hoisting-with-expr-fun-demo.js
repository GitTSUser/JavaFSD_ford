//program to demo function hoisting with an expression function


saySomething("Welcome to hoisting");

const saySomething=function(msg) {    
    console.log("Say: ",msg);
};


saySomething("Welcome to functions")
