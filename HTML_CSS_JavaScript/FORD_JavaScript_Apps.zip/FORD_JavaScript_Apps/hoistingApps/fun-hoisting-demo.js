//program to demo function hoisting

saySomething("Welcome to hoisting");

function saySomething(msg) {
    
    console.log("Say: ",msg);
}


saySomething("Welcome to functions");

