//program to demo the need of callback function

console.log("start of program")
function sum(x,y, cbFun) {

    setTimeout(()=>{ //asynchronous operation
       cbFun(x+y)
    },2000);
}


sum(10,20,(result)=>{
console.log(result);

 sum(result,40,(result)=>{
    console.log(result);
 })
});

console.log("end of program");