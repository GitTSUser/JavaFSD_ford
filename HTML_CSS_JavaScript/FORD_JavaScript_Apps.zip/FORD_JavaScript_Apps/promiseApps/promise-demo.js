//program to demonstrate promise creation and usage
function sum(x,y){

    const promise=new Promise((resolve,reject)=>{

        if(typeof x!=='number' || typeof y!=='number'){

            return reject(new Error("both x,y must be number type"))
        }

        resolve(x+y);

    });

    return promise;
}


//let sumPromise=sum(10,"hello");

sum(30,20).then((result)=>{
    console.log("sum of x,y is:",result);
}).catch(error=>{
    console.log("error is:",error.message);
})

//console.log("sum of x,y is:",sumPromise)