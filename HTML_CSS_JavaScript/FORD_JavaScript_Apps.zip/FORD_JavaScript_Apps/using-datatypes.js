//program to demonstrate using diff data types.

var x=10;
var y=20;

var z=x+y;

console.log("sum is:",z);
console.log(typeof x);
console.log(typeof y);

var firstName="Varun";

var secondName="Kumar";

console.log(firstName+secondName);
console.log(typeof firstName);
console.log(typeof secondName);


var isRaining=false;

console.log(typeof isRaining)

isRaining="Not raining";

console.log(typeof isRaining);